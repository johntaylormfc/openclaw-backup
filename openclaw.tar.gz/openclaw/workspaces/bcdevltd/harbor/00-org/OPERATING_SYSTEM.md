# Operating System (v0)

## Ticket flow
Idea → New → In Progress → Review → Done
- Harbor is gatekeeper for moving work into "In Progress".
- Inspector must sign off before "Done" unless explicitly waived.

## Cadence
- Harbor heartbeat: daily short update in HEARTBEAT.md
- Weekly: review backlog + archive stale items

## Working agreements
- Every task produces an artifact: PR, doc, runbook, checklist, or decision record.
- Prefer “small PRs often” over big-bang merges.
