# BC Dev Limited — Operating Map

## Roles (Agents)
- Harbor (HQ): triage, priorities, decisions, roadmap, final sign-off.
- Shipwright (Dev): implement changes, produce code and scripts.
- Inspector: review outputs, validate steps, test notes, reproduction steps.
- Sentinel: security & compliance checks (secrets, licenses, risky ops).
- Ledger: cost and model governance; token spend and alerts.
- Postmaster: stakeholder comms, release notes, email drafts.
- Archivist: documentation, ADRs, knowledge base upkeep.

## Workflow
Idea → New → In-progress → Review → Done  
Blocked can happen at any stage.
