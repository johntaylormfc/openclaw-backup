# Policies (v0)

## Approval policy
- NO deletes, force-push, credential changes, or production actions without explicit approval.
- Any action that changes remote systems requires: "APPROVED: <action>".

## Git policy
- Work on feature branches.
- PR required for merge to main/master.
- PR description must link to a ticket.

## Secrets & credentials
- Never commit secrets.
- Use environment variables / secret managers / GitHub secrets.
- Redact tokens from logs/screenshots.

## Cost policy
- Prefer the cheapest model that meets quality needs.
- If costs spike, Ledger must propose mitigations (routing/model changes).
