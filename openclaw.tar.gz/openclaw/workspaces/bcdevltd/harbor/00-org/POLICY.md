# BC Dev Limited — Policy (Owner: John)

Hard rules
- No deletions unless John explicitly says: "APPROVED: DELETE"
- No outbound comms (posting/sending/submitting/logging in to external services) unless John explicitly says: "APPROVED: OUTBOUND"
- Git workflow: feature branches + PRs only. No direct pushes to protected branches.
- If unsure, stop and ask John.

Notes
- Reading web pages for research is OK (when web/browser tools are enabled).
- Anything that causes side-effects outside this machine counts as outbound.
