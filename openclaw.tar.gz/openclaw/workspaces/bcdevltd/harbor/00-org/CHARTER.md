# BC Dev Limited — Charter (v0)

## Mission
Build and maintain Microsoft Dynamics 365 Business Central extensions/integrations with high quality, low operational toil, and predictable cost.

## Scope
- AL extension development, testing, CI, release management
- Issue triage and structured delivery (tickets → PRs → releases)
- Documentation/runbooks for repeatable ops

## Non-goals (for now)
- Fully autonomous changes pushed to production without approval
- Handling secrets outside approved stores

## Principles
- Safety first: no destructive actions without explicit approval.
- Small batches: prefer incremental PRs.
- Traceability: every change ties back to a ticket.
- Cost-aware: track model/token cost and avoid waste.

## Definition of Done (DoD)
- Ticket has acceptance criteria met
- Tests pass (where applicable)
- Docs/runbook updated if behavior/ops changed
- PR reviewed (human approval) before merge
