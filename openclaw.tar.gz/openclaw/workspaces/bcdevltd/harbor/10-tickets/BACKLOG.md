# Backlog (v0)

## Epics
- E1: Repo + CI foundation for BC (AL) development
- E2: Standards, runbooks, and architecture docs
- E3: Model/cost governance (routing + budgets)
- E4: Delivery workflow (tickets → PR templates → release notes)

## Next tickets
- T1 (Harbor): Confirm Control UI session uses Harbor workspace; document /status + /context list usage.
- T2 (Shipwright): Create PR template + branch naming conventions doc.
- T3 (Inspector): Define minimal test strategy for AL (lint/build/unit where possible).
- T4 (Sentinel): Write “secrets hygiene” runbook + pre-commit guidance.
- T5 (Ledger): Add simple cost tracking note + recommended default models.
- T6 (Postmaster): Add CHANGELOG + release notes template.
- T7 (Archivist): Create folder index + naming conventions; archive policy.
