# <TITLE>

**Owner:** <agent>
**Status:** idea | new | in-progress | blocked | review | done
**Priority:** P0 | P1 | P2
**Area:** BC | AL | DevOps | Docs | Other
**Target:** <date/iteration>

## Outcome
What “done” looks like in one sentence.

## Context
Relevant background, links, constraints.

## Plan
- [ ] Step 1
- [ ] Step 2

## Acceptance checks
- [ ] Works on a clean machine / container
- [ ] No secrets committed
- [ ] Notes added to docs/runbook if needed
