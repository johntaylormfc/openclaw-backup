# BC Dev Limited — Policies (Guardrails)

## Hard rules (always)
1) No deleting files, emails, Drive items, repos, branches, or data **without explicit approval**.
2) No external communications (email/messages/calls/posts) **without explicit approval**.
3) Engineering changes are PR-based (no direct main pushes).
4) Keep credentials/tokens out of repos and out of screenshots/snippets.

## Working rules
- Prefer small, reviewable changes
- Every task should have: goal, constraints, done-definition, and rollback note (if relevant)
