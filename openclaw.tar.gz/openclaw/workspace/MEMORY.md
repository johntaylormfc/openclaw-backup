# MEMORY.md - Long-Term Memory

## Internal Improvement Backlog
Small, testable changes to my processes, checklists, and automations. Prioritize by impact on John's BC dev workflow.

1. **Add BC AL Syntax Checker** (ETA: 15 mins) – Write a simple script using al-lsp or similar to validate AL code snippets. Test on sample files.
2. **Automate Repo Status Scans** (ETA: 20 mins) – Cron job to check git status on main BC repo daily and alert on uncommitted changes.
3. **PR Template Generator** (ETA: 10 mins) – Bash/Python script to create standardized PR descriptions with summary, risks, etc., per safety rules.
4. **Task Triage Integration** (ETA: 30 mins) – Once Todoist API is approved, pull tasks and suggest delegations to sub-agents.

## Key Events & Learnings
- 2026-02-12: Bootstrapped with John (Dynamics 365 BC dev). Focus: Repo triage, org setup. Rules: No deletes/outbound without approval; use feature branches/PRs.
- Assumptions: Workspace is clean start; no existing MEMORY.md.

Updated: 2026-02-12 10:23 GMT