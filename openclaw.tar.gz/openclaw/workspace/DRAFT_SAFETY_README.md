# GitHub Org Safety & Workflow Guide
For johntaylormfc org (initial repos: GM, Contracts). Draft for review – do not publish yet.

## Core Rules (Non-Negotiable)
1. **No Deletions/Destructive Actions**: Require explicit \"APPROVED: DELETE\" from John.
2. **No External Comms**: No emails, posts, or third-party contacts without \"APPROVED: OUTBOUND\".
3. **Least Privilege**: Read-only by default; changes via PRs.
4. **GitHub Protections**:
   - Protect main/master branches (require PR reviews).
   - All changes via feature branches (e.g., feat/triage-20260212).
   - PRs must include:
     - **Summary**: What/why.
     - **Scope/Files Changed**: List affected.
     - **Risks**: Potential issues.
     - **Verification**: How to test.
     - **Rollback**: Revert steps if needed.

## Branching Strategy
- `main`: Stable, production-ready.
- `develop`: Integration branch for ongoing work.
- Feature branches: `feat/<description>`, `fix/<issue>`, `hotfix/<urgent>`.
- Use `gh` CLI for all interactions (per skill).

## PR Template
Use this in .github/pull_request_template.md:

```
## Summary
[Brief description]

## Scope/Files Changed
- file1.al
- ...

## Risks
- Potential BC runtime errors if untested.

## Verification
- Run AL tests: `al test`
- Manual review in sandbox.

## Rollback
- Revert commit: `git revert <hash>`
```

## Automation Notes
- OpenClaw agent handles triage, suggestions.
- Sub-agents for isolated tasks (spawn via sessions_spawn).

Review & approve before creating org/repos. Updated: 2026-02-12