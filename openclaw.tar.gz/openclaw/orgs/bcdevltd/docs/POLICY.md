# BC Dev Limited — Policy (John is owner)

Hard rules
- No deletions without John's exact approval: "APPROVED: DELETE"
- No outbound comms to people/systems (email/chat/posting/forms/submitting) without: "APPROVED: OUTBOUND"
- GitHub: no pushes to protected branches; use feature branches + PRs; PR must include summary, risks, verification steps.

Web/Browser note
- Reading web pages is allowed for research when enabled.
- Submitting forms, logging in, posting comments/issues, sending messages = outbound comms → requires approval.
