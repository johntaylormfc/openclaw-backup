# BC Dev Limited — Internal Tasks

## How this works
- John adds tasks here OR agents propose tasks here.
- Agents only execute tasks marked ✅ Approved by John.
- No outbound comms. No deletions. No pushes to GitHub unless John explicitly approves.

## Task board
| ID | Created | Owner | Title | Status | ETA | Blockers | Approved? |
|---:|---|---|---|---|---|---|---|
| 1 | 2026-02-12 | Harbor | Bootstrap org + guardrails | Doing | 30m | - | ✅ |
