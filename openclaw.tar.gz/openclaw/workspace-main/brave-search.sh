#!/bin/bash
KEY="BSAC9g98qhbaRQlELoLGXD4bnMIDYjl"
QUERY="$1"
curl -s -H "X-Subscription-Token: $KEY" "https://api.search.brave.com/res/v1/search?q=$QUERY" | jq '.web.results[] | {title: .title, description: .description, url: .url}' | head -10
