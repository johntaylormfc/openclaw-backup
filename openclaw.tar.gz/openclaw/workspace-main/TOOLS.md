# TOOLS.md - Local Notes

## Brave Search API
- Key: BSAC9g98qhbaRQlELoLGXD4bnMIDYjl
- Endpoint: https://api.search.brave.com/res/v1/search/create
- Usage: curl -H "X-Subscription-Token: $KEY" "https://api.search.brave.com/res/v1/search?q=query" | jq '.web.results[].title, .web.results[].description'

## Backup
- Script: bcdevltd/backup.sh (hourly cron ready)
- Repo: johntaylormfc/openclaw-backup

## Repos
- GM: https://github.com/johntaylormfc/GM
- Contracts: https://github.com/johntaylormfc/Contracts

Updated: 2026-02-12