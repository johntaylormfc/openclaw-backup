# Hourly Updates (while John away)

1. Check portal: curl http://127.0.0.1:8000 (status)
2. Repo triage: gh auth status + repo summary (johntaylormfc/GM, Contracts)
3. Tasks: cat bcdevltd/tasks/internal_tasks.md + backlog
4. Status: openclaw gateway status --deep --json > bcdevltd/status/status.json
5. Brief summary message if changes/pending (e.g. "Portal OK, repos ready for auth, Stage 2 cron pending GO")

If no changes: HEARTBEAT_OK