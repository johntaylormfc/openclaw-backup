# GM Extension Test Configuration

This document outlines the testing configuration and automated testing setup for the GM Business Central extension.

## Test Framework Integration

The GM extension uses the Business Central Test Framework with the following test codeunits:

- **GMLoyaltyAPITests.Codeunit.al** (ID: 69701) - API endpoint testing
- **GMSalesPostingTests.Codeunit.al** (ID: 69702) - Sales posting validation
- **LibraryLoyaltyGM.Codeunit.al** (ID: 69703) - Test utility functions
- **GMTestDataSetup.Codeunit.al** (ID: 69706) - Test data management

## Test Categories

### 1. API Testing
- **Purpose**: Validate all API endpoints for proper error handling and data integrity
- **Coverage**: All 20+ OData API endpoints
- **Key Areas**:
  - Authentication and authorization
  - Error handling with ErrorInfo objects
  - Data validation and business rules
  - Performance under load

### 2. Sales Posting Testing
- **Purpose**: Ensure sales document posting works correctly with GM customizations
- **Coverage**: Event subscribers and business logic validation
- **Key Areas**:
  - Order validation before posting
  - Shipment scheduling updates
  - Loyalty points calculation
  - Error handling in posting processes

### 3. Loyalty System Testing
- **Purpose**: Validate loyalty participant management and points processing
- **Coverage**: Loyalty tables, calculations, and business rules
- **Key Areas**:
  - Participant registration and validation
  - Points calculation and redemption
  - Reward processing
  - Status management

## Automated Test Execution

### Test Suite Configuration

```json
{
  "testSuites": [
    {
      "name": "GM API Tests",
      "codeunitId": 69701,
      "category": "API",
      "timeout": 300000,
      "retries": 2
    },
    {
      "name": "GM Sales Posting Tests", 
      "codeunitId": 69702,
      "category": "Business Logic",
      "timeout": 180000,
      "retries": 1
    },
    {
      "name": "GM Loyalty Tests",
      "codeunitId": 69703,
      "category": "Loyalty",
      "timeout": 120000,
      "retries": 1
    }
  ]
}
```

### Continuous Integration Setup

#### Azure DevOps Pipeline Configuration

```yaml
# azure-pipelines.yml
trigger:
  branches:
    include:
      - main
      - develop
      - feature/*

pool:
  vmImage: 'windows-latest'

variables:
  bcVersion: '26.0'
  containerImage: 'mcr.microsoft.com/businesscentral/sandbox:$(bcVersion)'

stages:
- stage: Build
  jobs:
  - job: CompileExtension
    steps:
    - task: ALOpsDockerCreate@1
      displayName: 'Create BC Container'
      inputs:
        containerName: 'bcserver'
        artifactUrl: '$(containerImage)'
        
    - task: ALOpsDockerStart@1
      displayName: 'Start BC Container'
      inputs:
        containerName: 'bcserver'
        
    - task: ALOpsAppCompiler@2
      displayName: 'Compile GM Extension'
      inputs:
        usedocker: true
        containerName: 'bcserver'
        appProjectFolder: '.'
        appOutputFile: '$(Build.ArtifactStagingDirectory)/GM.app'

- stage: Test
  dependsOn: Build
  jobs:
  - job: RunTests
    steps:
    - task: ALOpsDockerStart@1
      displayName: 'Start BC Container'
      inputs:
        containerName: 'bcserver'
        
    - task: ALOpsAppPublish@1
      displayName: 'Publish GM Extension'
      inputs:
        usedocker: true
        containerName: 'bcserver'
        appFile: '$(Build.ArtifactStagingDirectory)/GM.app'
        
    - task: ALOpsAppTest@1
      displayName: 'Run GM Tests'
      inputs:
        usedocker: true
        containerName: 'bcserver'
        testSuite: 'GM'
        testFilter: 'CODEUNIT 69701..69703'
        exportTestResults: true
        testResultsFile: '$(Build.ArtifactStagingDirectory)/TestResults.xml'
        
    - task: PublishTestResults@2
      displayName: 'Publish Test Results'
      inputs:
        testResultsFormat: 'JUnit'
        testResultsFiles: '$(Build.ArtifactStagingDirectory)/TestResults.xml'
        mergeTestResults: true
```

#### GitHub Actions Configuration

```yaml
# .github/workflows/ci.yml
name: GM Extension CI

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  build-and-test:
    runs-on: windows-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup BC Container
      uses: microsoft/AL-Go-Actions/CreateReleaseEnvironment@main
      with:
        bcVersion: '26.0'
        
    - name: Compile Extension
      uses: microsoft/AL-Go-Actions/BuildALApp@main
      with:
        projectPath: '.'
        
    - name: Run Tests
      uses: microsoft/AL-Go-Actions/RunTests@main
      with:
        testFilter: 'CODEUNIT 69701..69703'
        
    - name: Publish Test Results
      uses: dorny/test-reporter@v1
      if: always()
      with:
        name: GM Extension Tests
        path: '**/TestResults.xml'
        reporter: jest-junit
```

## Test Data Management

### Test Data Setup
- **GMTestDataSetup.Codeunit.al** provides standardized test data creation
- Creates customers, items, loyalty participants, and sales documents
- Uses unique identifiers to avoid conflicts with existing data

### Test Data Cleanup
- Automatic cleanup after each test run
- Removes all test-specific records
- Preserves existing business data

### Test Data Categories

1. **Basic Master Data**
   - Test customers with credit limits
   - Test items with pricing
   - Unit of measures and posting groups

2. **Loyalty Test Data**
   - Active loyalty participants
   - Points balances and transaction history
   - Reward definitions and redemptions

3. **Sales Document Test Data**
   - Sales orders with multiple lines
   - Different document states (pending, confirmed, shipped)
   - Various customer and item combinations

## Performance Testing

### Test Performance Metrics
- API response times (target: < 500ms for single records)
- Sales posting duration (target: < 2s per document)
- Loyalty operations (target: < 1s per transaction)

### Load Testing Configuration
```al
// Performance thresholds
MaxAPIResponseTime := 500; // milliseconds
MaxSalesPostingTime := 2000; // milliseconds  
MaxLoyaltyOperationTime := 1000; // milliseconds

// Load test parameters
ConcurrentUsers := 10;
TestDuration := 300; // seconds
RequestsPerSecond := 50;
```

## Test Coverage Goals

### API Testing Coverage
- ✅ Authentication/Authorization: 100%
- ✅ CRUD Operations: 100% 
- ✅ Error Handling: 100%
- ✅ Business Rule Validation: 95%
- ⏳ Performance Under Load: 80%

### Business Logic Coverage
- ✅ Sales Posting Events: 100%
- ✅ Loyalty Calculations: 95%
- ⏳ Order Status Management: 90%
- ⏳ Credit Control Integration: 85%

### Integration Testing Coverage
- ⏳ External API Integration: 70%
- ⏳ Web Service Consumption: 80%
- ⏳ Database Triggers: 95%

## Test Reporting

### Daily Test Reports
- Automated test execution results
- Performance trend analysis
- Code coverage metrics
- Failed test investigations

### Weekly Test Summary
- Test suite health dashboard
- Performance benchmark comparisons
- Technical debt assessment
- Recommended improvements

### Test Metrics Dashboard

Key metrics tracked:
- **Pass Rate**: Target 98%
- **Average Test Duration**: Target < 5 minutes
- **Code Coverage**: Target 90%
- **Performance Regression**: Alert on 20% degradation

## Integration with Development Workflow

### Pre-Commit Testing
```powershell
# Pre-commit hook script
./tools/run-quick-tests.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Error "Tests failed. Commit blocked."
    exit 1
}
```

### Pull Request Testing
- Automated test execution on PR creation
- Performance impact analysis
- Code coverage delta reporting
- Required passing tests before merge

### Release Testing
- Full regression test suite
- Performance benchmark validation
- Integration test execution
- User acceptance test scenarios

## Troubleshooting Test Issues

### Common Test Failures
1. **Data Setup Issues**: Ensure test data cleanup ran successfully
2. **Permission Errors**: Verify test user has required permissions
3. **Timing Issues**: Check for race conditions in async operations
4. **Environment Conflicts**: Ensure clean test environment

### Debug Test Execution
```al
// Enable detailed test logging
TestLoggingEnabled := true;
DebugMode := true;

// Test execution with debugging
RunTestWithDebug('GMLoyaltyAPITests', 'TestValidateParticipantForReward');
```

### Test Environment Reset
```powershell
# Reset test environment script
./tools/reset-test-environment.ps1 -ContainerName "bctest" -FullReset
```

This testing configuration ensures comprehensive validation of the GM extension functionality while supporting efficient development workflows and continuous improvement.