# GM API Quick Reference

Columns: entity set name, source table, brief purpose. Grouped for quick scanning.

**Sales – Unposted**

| Entity Set | Source Table | Description |
| --- | --- | --- |
| unpostedSalesInvoices | Sales Header | Unposted sales invoices (document type filter). |
| unpostedSalesInvoiceLines | Sales Line | Lines for unposted sales invoices. |
| unpostedSalesInvoicesWithLines | Sales Header | Unposted sales invoices with lines. |
| salesOrders | Sales Header | Sales order headers. |
| salesOrderLines | Sales Line | Sales order lines. |
| salesOrdersWithLines | Sales Header | Sales orders with lines. |
| salesOrderItemAvailabilities | Sales Line | Item availability for sales order lines. |
| salesReturnOrders | Sales Header | Sales return order headers. |
| salesReturnOrderLines | Sales Line | Sales return order lines. |
| salesReturnOrdersWithLines | Sales Header | Sales return orders with lines. |

**Sales – Posted**

| Entity Set | Source Table | Description |
| --- | --- | --- |
| postedSalesInvoices | Sales Invoice Header | Posted sales invoices (header only). |
| postedSalesInvoicesWithLines | Sales Invoice Header | Posted sales invoices with line expansion. |
| postedSalesInvoiceLines | Sales Invoice Line | Lines for posted sales invoices. |
| postedSalesCreditMemos | Sales Cr.Memo Header | Posted sales credit memo headers. |
| postedSalesCreditMemosWithLines | Sales Cr.Memo Header | Posted sales credit memos with line expansion. |

**Purchase – Unposted & Returns**

| Entity Set | Source Table | Description |
| --- | --- | --- |
| purchaseOrders | Purchase Header | Purchase orders with post receipt action. |
| purchaseOrderLines | Purchase Line | Purchase order lines. |
| purchaseOrdersWithLines | Purchase Header | Purchase orders with line expansion. |
| purchaseReturnOrders | Purchase Header | Purchase return order headers. |
| purchaseReturnOrderLines | Purchase Line | Purchase return order lines. |
| purchaseReturnOrdersWithLines | Purchase Header | Purchase return orders with lines. |
| purchaseComments | Purch. Comment Line | Purchase document comment lines. |

**Purchase – Posted**

| Entity Set | Source Table | Description |
| --- | --- | --- |
| postedPurchaseInvoices | Purch. Inv. Header | Posted purchase invoices (header only). |
| postedPurchaseInvoicesWithLines | Purch. Inv. Header | Posted purchase invoices with line expansion. |
| postedPurchaseInvoiceLines | Purch. Inv. Line | Lines for posted purchase invoices. |

**Reference & Master Data**

| Entity Set | Source Table | Description |
| --- | --- | --- |
| customers | Customer | Customer master data (v1). |
| customers | Customer | Customer master data (v2 schema). |
| contacts | Contact | Access to contact master data. |
| items | Item | Item master data. |
| vendors | Vendor | Vendor master data. |
| salespersonPurchasers | Salesperson/Purchaser | Salesperson or purchaser master data. |
| shipToAddresses | Ship-to Address | Ship-to addresses per customer. |
| shipmentMethods | Shipment Method | Shipment method codes. |
| orderAddresses | Order Address | Order address records. |
| orderStatuses | Order Status | Order status codes. |
| productGroups | Product Group | Product group definitions. |
| lookups | Lookups | Generic lookup values for GM extensions. |
| strategies | Strategy | Strategy records for farm/milk operations. |
| creditComments | Credit Comment Line | Manage credit control comments. |
| salesComments | Sales Comment Line | Sales document comment lines. |
| loyaltyParticipants | Loyalty Participants | Loyalty participants with bound actions. |
| loyaltyComments | Loyalty Comments | Comments attached to loyalty records. |
| loyaltySetups | Loyalty Setup | Loyalty setup configuration. |

**Operations / Inventory**

| Entity Set | Source Table | Description |
| --- | --- | --- |
| cashReceiptBatches | Gen. Journal Batch | Manages cash receipt journal batches. |
| custLedgerEntries | Cust. Ledger Entry | Read customer ledger entries. |
| inventoryCostingOps | Inventory Setup | Inventory costing configuration exposure. |
| productionSchedules | Production Schedule | Production schedule headers. |
| transferOrders | Transfer Header | Transfer orders with post actions. |
| bomComponents | BOM Component | Exposes production BOM component lines. |
