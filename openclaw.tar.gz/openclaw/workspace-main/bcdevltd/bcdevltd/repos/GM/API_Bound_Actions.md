# Bound Actions Overview

| Action | API Page | Entity Set | Notes |
| --- | --- | --- | --- |
| PostPurchaseOrderReceipt | src/API/PurchaseOrderPostAPI.Page.al | purchaseOrders | Receive only; returns Deleted |
| PostPurchaseOrderInvoice | src/API/PurchaseOrderPostAPI.Page.al | purchaseOrders | Invoice only; returns Deleted |
| ReleasePurchaseOrder | src/API/PurchaseOrderPostAPI.Page.al | purchaseOrders | Manual release |
| ReopenPurchaseOrder | src/API/PurchaseOrderPostAPI.Page.al | purchaseOrders | Manual reopen |
| PostDefaultCashReceiptBatch | src/API/CashReceiptBatchAPI.Page.al | cashReceiptBatches | Posts batch CASHRCPT/DEFAULT |
| PostShopifyCashReceiptBatch | src/API/CashReceiptBatchAPI.Page.al | cashReceiptBatches | Posts batch CASHRCPT/SHOPIFY |
| RunAdjustCost | src/API/InventoryCostingOpsAPI.Page.al | inventoryCostingOps | Runs Adjust Cost (report) |
| RunCalcStdCost | src/API/InventoryCostingOpsAPI.Page.al | inventoryCostingOps | Std cost calc via codeunit |
| RunCalcStandardCosts | src/API/InventoryCostingOpsAPI.Page.al | inventoryCostingOps | Std cost shares update |
| ManualRewardPost | src/API/CustomerAPI.Page.al; src/API/CustomerAPIv2.Page.al | customers | Posts reward (BusinessGroup='AGRI') |
| ManualRewardPostBG | src/API/CustomerAPI.Page.al; src/API/CustomerAPIv2.Page.al | customers | Posts reward with BusinessGroup |
| PostSalesOrderShipment | src/API/SalesOrderAPI.Page.al | salesOrders | Ship=true, Invoice=false |
| PostSalesOrderInvoice | src/API/SalesOrderAPI.Page.al | salesOrders | Ship=false, Invoice=true |
| ReopenSalesOrder | src/API/SalesOrderAPI.Page.al | salesOrders | Manual reopen |
| PostSalesReturnReceipt | src/API/SalesReturnOrderAPI.Page.al | salesReturnOrders | Receive return order |
| PostTransferShipment | src/API/TransferOrderAPI.Page.al | transferOrders | Post transfer shipment |
| PostTransferReceipt | src/API/TransferOrderAPI.Page.al | transferOrders | Post transfer receipt |
| UpdateInvoicePrinted | src/API/GMPostedSalesInvoiceAPI.Page.al | postedSalesInvoices | Mark posted invoice printed |
| UpdateCreditMemoPrinted | src/API/PostedSalesCreditMemoAPI.Page.al | postedSalesCreditMemos | Mark posted credit memo printed |
| PostProductionSchedule | src/API/ProductionScheduleAPI.Page.al | productionSchedules | Posts item journal lines |
| ExportPromtek | src/API/ProductionScheduleAPI.Page.al | productionSchedules | Returns explanatory error (export not available in SaaS) |
| ManualReward | src/API/LoyaltyParticipantsAPI.Page.al | loyaltyParticipants | Participant manual reward |
| Redemption | src/API/LoyaltyParticipantsAPI.Page.al | loyaltyParticipants | Participant redemption |
