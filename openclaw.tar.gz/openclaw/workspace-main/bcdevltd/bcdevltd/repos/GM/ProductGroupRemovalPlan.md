
# Product Group Table Removal Plan

## Context
- **Goal:** Remove the custom `Product Group` table (65620) and reroute all features to rely solely on the standard `Item Category` table, freeing the `Product Group Code` concept to be a derived value (e.g., the `Item Category Code` or a dimension) rather than an independent master table.
- **Why it matters:** The `Product Group` table drives dimensions, flowfields, reports, pages, APIs, and loyalty rules that are tightly coupled to the `Product Group Code`. Removing it touches a wide swath of the extension, so we need an ordered migration plan.

## Current Footprint

### Table & Reporting Data
- `Table 65620 "Product Group"` stores `Item Category Code`, `Code`, `Description`, `Warehouse Class Code`, and ~30 flowfields that aggregate `Value Entry` data via the `Global Dimension 2 Code` that mirrors the `Code` field. This table feeds the `Product Groups` page and `ProductGroups API` and powers reports such as `CostOfSalesByProdGroup`, `CustomerLoyalty`, `AgriSales`, `SlowMovingStock`, and `StdCostVLastDirectCost` through filters and flowfields.
- The table also exposes `FlowFilters` (date, salesperson, inventory posting group) that are referenced in several reports and business processes.

### Item-Level Fields & Dimensions
- `Item Ext` introduces `"Product Group Code"` with a `TableRelation` back to `Product Group` filtered by the current `Item Category Code`. The ONVALIDATE logic enforces costing-method rules, syncs the `PRODUCTGROUP` default dimension, and keeps `Global Dimension 2 Code` in sync with the product group value. Cross logic assumes the `Product Group Code` drives both reporting dimensions and loyalty behavior.

### Table Extensions & Business Logic
- Line extensions (`Sales Line`, `Sales Shipment Line`, `Sales Credit Memo Line`, `Sales Invoice Line`, `Shipment Scheduling`) add a `"Product Group Code"` field that relates to the Product Group table, copy values from the Item, and use that field in filtering (e.g., `SO.SetRange(Type, SO.Type::"Product Group")`).
- `PointSpecialOffers` stores `"Product Group"` as part of the `Target` option set.
- Loyalty tables (`LoyaltyEntry`, `LoyaltyRegister`, `LoyaltyParticipants`, `LoyaltySetup`, `LoyaltyRegister`, `LoyaltyEntry`) copy the item-level product group into entries, use it in filters, and link it to `Default Dimension` `'PRODUCTGROUP'` values.
- `GMLoyaltySubscriptions` repeatedly sets `LoyaltyEntry."Product Group"` based on the item.

### Pages & APIs
- `Page 65600 "Product Groups"` and `API 65636 "Product Groups API"` are direct CRUD surfaces for the table.
- `Item Card`, `Items by Location Matrix`, and `Shipment Schedule` page extensions expose the `Product Group Code` field from the item and use it as a RunPageLink target or filter.
- `Outstanding Order/Invoice Lines`, `Loyalty Register`, `Loyalty Entries`, and `Loyalty Setup` pages expose product group filters, and several custom request pages (e.g., `SlowMovingStock`, `CustomerLoyalty`, `StdCostVLastDirectCost`) surface `Product Group` fields/filters.
- APIs (`Item API`, `Sales Order Line API`, `Product Groups API`) expose the product group field for consumption by external integrations.

### Reports & Process Pages
- Reports such as `CustomerLoyalty`, `SlowMovingStock`, `StdCostVLastDirectCost`, `Galloway & Macleod` `CostOfSalesByProdGroup`, `AgriSales`, `CountryLeisureBusinessPlan`, and `AgriSalesValue` filter by or display `Product Group Code` and may load item records with `Product Group Code` in place.
- `Shipment Scheduling` table/page includes `Product Group Code` fields, lookups, and report totals.

### Permissions & Table Data Rights
- Both `GM.PermissionSet.al` and `src/PermissionSets/GMExtension.PermissionSet.al` grant `RIMD` table data and `X` table/page access to `Product Group` plus its page and REST API.

## Migration Strategy

1. **Retire the `Product Group` table and its pages/APIs.**
   - Remove `Product Group` table definition, `ProductGroups` page, and `Product Groups API`. Ensure any open REST or page references are updated to use `Item Category` or a new lookup.
   - Migrate the aggregated `FlowField` reports (value entry summaries, salesperson splits, tonnage totals) to either existing `Item Category` flowfields or to a new report/table that filters by `Item Category` directly.

2. **Rework the item-level metadata.**
   - Replace or remove the `Product Group Code` field on `Item`. If the goal is to treat `Item Category` as the single master, the new field should simply read the `Item Category Code` (or another derived value) without pointing to the removed table.
   - Update the dimension syncing logic so that items still maintain the `PRODUCTGROUP` default dimension (if this dimension still needs to exist) – either by mirroring the `Item Category` code or by deprecating that dimension entirely.
   - Reevaluate the costing-method switch in `OnValidate` (currently tied to product group values `0501/0503/0507/5701`) to ensure business rules still run after the field is repointed.

3. **Clean up table extensions and business logic using Product Group.**
   - Remove the `Product Group Code` fields from `Sales Line`, `Sales Shipment Line`, `Sales Credit Memo Line`, `Sales Invoice Line`, and `Shipment Scheduling`. Replace any filtering logic that relied on the `Product Group` table with `Item Category Code` or directly use the `PRODUCTGROUP` dimension on the related tables.
   - Update `PointSpecialOffers` option set to remove the `Product Group` entry or to reinterpret it as an `Item Category` selection.
   - Revise the loyalty tables/codeunits so they record either the `Item Category Code` or the new consolidated group representation instead of the removed table. This includes `GMLoyaltySubscriptions` logic that copies from `Item."Product Group Code"` and any calculations that used the table relation.

4. **Adjust downstream pages, APIs, and reports.**
   - Remove requests that surface `Product Group` filters and add `Item Category` equivalents (or `Default Dimension` filters if dimension 2 is the new source).
   - Update the `Item Card`, `Shipment Schedule`, `Items by Location Matrix`, and any other page extensions so they no longer show/require a `Product Group Code` lookup. If needed, point the RunPageLink/exposed fields to `Item Category` pages instead.
   - Update APIs (`Item API`, `Sales Order Line API`) to stop serializing the removed field or to provide new fields derived from `Item Category`.
   - Rebuild reports (`CustomerLoyalty`, `SlowMovingStock`, `StdCostVLastDirectCost`, `CostOfSalesByProdGroup`, `AgriSales`, etc.) so that they filter/group against `Item Category` or the new consolidated group dimension.

5. **Reconcile permissions.**
   - Remove the `Product Group` table/page/API rights from all permission sets and ensure the new target (e.g., `Item Category` plus any new codeunit/table) has the appropriate grants.

6. **Data migration & cleanup.**
   - Decide how existing product group records map to item categories (e.g., every `Product Group.Code` should map to exactly one `Item Category.Code`). If these are identical, document the mapping and update records accordingly.
   - Remove/cleanup `Default Dimension` records (`Table ID = 65620` or `Dimension Code = PRODUCTGROUP`) as part of the transition; instead, point loyalty and reporting logic at the `Item Category` dimension or `Item Category Code` values.

## Testing & Validation
- Run the `SlowMovingStock`, `CustomerLoyalty`, `StdCostVLastDirectCost`, `Shipment Schedule`, and `Agri` reports to confirm filters work once `Product Group` fields have been replaced.
- Validate `Loyalty` pages/entries still honor filtering without relying on the removed table.
- Ensure `Item` and line-level APIs still return meaningful group/category metadata for integrations.
- Confirm permission sets compile without references to `Product Group` objects.
- Smoke-test the `Item Card`, `Shipment Schedule`, and `Outstanding Order/Invoice Lines` pages to ensure the UI no longer requires an inexistent lookup table.

## Risks & Open Questions
- **FlowField coverage:** The `Product Group` table aggregated dozens of flowfields (e.g., `Total Sales`, salesperson splits, tonnage totals). We need to decide whether those analytics move onto `Item Category` or whether a new reporting table/dataset replicates them.
- **Loyalty and costing rules:** Business rules triggered by specific product group codes (0501/0503/0507/5701) need to be redefined. Are those codes still valid item categories, or do we need a new mapping table?
- **Item-to-ProductGroup mapping:** If multiple product groups shared one item category (or vice versa), we must define the canonical `Item Category` value after migration so logic stays deterministic.
- **Dimension usage:** The `Product Group` table tied closely to the `PRODUCTGROUP` default dimension (`Global Dimension 2`). Removing the table means we must decide whether that dimension still exists or if we reuse a different dimension (e.g., `Item Category`).