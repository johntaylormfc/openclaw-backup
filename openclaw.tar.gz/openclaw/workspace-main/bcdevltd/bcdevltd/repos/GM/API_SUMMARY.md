# GM Business Central API Summary

This document provides a comprehensive overview of all API pages in the GM Business Central extension, their usage, and available bound actions.

## Table of Contents
- [Overview](#overview)
- [API Configuration](#api-configuration)
- [Custom GM Table APIs](#custom-gm-table-apis)
- [Standard Business Central Table APIs](#standard-business-central-table-apis)
- [Bound Actions Reference](#bound-actions-reference)
- [Usage Examples](#usage-examples)
- [Authentication](#authentication)

## Overview

The GM Business Central extension exposes **20 API pages** that provide OData v4 access to both custom GM tables and standard Business Central entities. These APIs replace the legacy SOAP-based web services used in Microsoft Navision 5.0.

### API Standards
- **API Publisher**: `bcdev`
- **API Group**: `operations`
- **API Version**: `v1.0`
- **Protocol**: OData v4
- **Key Field**: `SystemId` (GUID)

## API Configuration

### Base URL
```
https://api.businesscentral.dynamics.com/v2.0/{tenantId}/{environment}/api/bcdev/operations/v1.0/companies({companyId})
```

### Environment Details
- **Tenant ID**: `5f10a982-8c82-4eb2-92db-a0cd54b2f754`
- **Environment**: `Sandbox`
- **Company ID**: `848fd9f3-6795-f011-b419-7c1e5279eaf3`

### Complete Base URL
```
https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)
```

## Custom GM Table APIs

### 1. Contact Comments API (Credit Comments)
**Entity Set**: `creditComments`  
**Entity Name**: `creditComment`  
**Source Table**: Credit Comment Line (Custom)  
**Bound Actions**: None

**Purpose**: Manage credit control comment lines.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/creditComments
```

**Key Fields**:
- `systemId` - Unique identifier
- `documentType` - Document type
- `no` - Document number
- `lineNo` - Line number
- `date` - Comment date
- `comment` - Comment text

---

### 2. Loyalty Comments API
**Entity Set**: `loyaltyComments`  
**Entity Name**: `loyaltyComment`  
**Source Table**: Loyalty Comments (65608)  
**Bound Actions**: None

**Purpose**: Manage comments for loyalty program participants.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyComments
```

**Key Fields**:
- `systemId` - Unique identifier
- `participantId` - Loyalty participant ID
- `lineNo` - Line number
- `date` - Comment date
- `code` - Comment code
- `comment` - Comment text

---

### 3. Loyalty Participants API
**Entity Set**: `loyaltyParticipants`  
**Entity Name**: `loyaltyParticipant`  
**Source Table**: Loyalty Participants (65607)  
**Bound Actions**: **ManualReward**, **Redemption**

**Purpose**: Manage loyalty program participants and process loyalty point transactions.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants
```

**Key Fields**:
- `id` - System ID (SystemId)
- `participantId` - Participant ID number
- `type` - Type (Retail/Agri)
- `cardNo` - Card number
- `name` - Participant name
- `address`, `city`, `postCode` - Address details
- `phoneNo`, `mobileNo`, `email` - Contact details
- `customerNo` - Linked customer number
- `status` - Active/Inactive
- `blocked` - Blocked flag

**Bound Actions**:
1. **ManualReward** - Award loyalty points manually
2. **Redemption** - Redeem loyalty points

---

### 4. Order Status API
**Entity Set**: `orderStatuses`  
**Entity Name**: `orderStatus`  
**Source Table**: Order Status (Custom)  
**Bound Actions**: None

**Purpose**: Manage order status codes and descriptions.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/orderStatuses
```

---

### 5. Product Groups API
**Entity Set**: `productGroups`  
**Entity Name**: `productGroup`  
**Source Table**: Product Group (Custom)  
**Bound Actions**: None

**Purpose**: Manage product group definitions.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/productGroups
```

---

### 6. Production Schedule API
**Entity Set**: `productionSchedules`  
**Entity Name**: `productionSchedule`  
**Source Table**: Production Schedule (Custom)  
**Bound Actions**: None

**Purpose**: Manage production schedules.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/productionSchedules
```

---

### 7. Strategy API
**Entity Set**: `strategies`  
**Entity Name**: `strategy`  
**Source Table**: Strategy (Custom)  
**Bound Actions**: None

**Purpose**: Manage strategy records for milk producers.

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/strategies
```

---

## Standard Business Central Table APIs

### 8. Contact API
**Entity Set**: `contacts`  
**Entity Name**: `contact`  
**Source Table**: Contact (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/contacts
```

---

### 9. Customer API
**Entity Set**: `customers`  
**Entity Name**: `customer`  
**Source Table**: Customer (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers
```

**Purpose**: Access and manage customer master data.

---

### 10. Item API
**Entity Set**: `items`  
**Entity Name**: `item`  
**Source Table**: Item (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/items
```

**Purpose**: Access and manage item master data.

---

### 11. Posted Sales Credit Memo API
**Entity Set**: `postedSalesCreditMemos`  
**Entity Name**: `postedSalesCreditMemo`  
**Source Table**: Sales Cr.Memo Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/postedSalesCreditMemos
```

---

### 12. Posted Sales Invoice API
**Entity Set**: `postedSalesInvoices`  
**Entity Name**: `postedSalesInvoice`  
**Source Table**: Sales Invoice Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/postedSalesInvoices
```

---

### 13. Purchase Order Post API
**Entity Set**: `purchaseOrders`  
**Entity Name**: `purchaseOrder`  
**Source Table**: Purchase Header (BC Standard)  
**Bound Actions**: **PostPurchaseOrderReceipt**

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders
```

**Purpose**: Manage purchase orders and post receipts.

**Bound Actions**:
1. **PostPurchaseOrderReceipt** - Post purchase order receipt (goods received)

---

### 14. Purchase Return Order API
**Entity Set**: `purchaseReturnOrders`  
**Entity Name**: `purchaseReturnOrder`  
**Source Table**: Purchase Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseReturnOrders
```

---

### 15. Sales Invoice API
**Entity Set**: `salesInvoices`  
**Entity Name**: `salesInvoice`  
**Source Table**: Sales Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/salesInvoices
```

**Note**: Automatically filters to `Document Type::Invoice`

---

### 16. Sales Order API
**Entity Set**: `salesOrders`  
**Entity Name**: `salesOrder`  
**Source Table**: Sales Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/salesOrders
```

**Note**: Automatically filters to `Document Type::Order`

---

### 17. Sales Return Order API
**Entity Set**: `salesReturnOrders`  
**Entity Name**: `salesReturnOrder`  
**Source Table**: Sales Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/salesReturnOrders
```

**Note**: Automatically filters to `Document Type::"Return Order"`

---

### 18. Salesperson Purchaser API
**Entity Set**: `salespersonPurchasers`  
**Entity Name**: `salespersonPurchaser`  
**Source Table**: Salesperson/Purchaser (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/salespersonPurchasers
```

---

### 19. Transfer Order API
**Entity Set**: `transferOrders`  
**Entity Name**: `transferOrder`  
**Source Table**: Transfer Header (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/transferOrders
```

---

### 20. Vendor API
**Entity Set**: `vendors`  
**Entity Name**: `vendor`  
**Source Table**: Vendor (BC Standard)  
**Bound Actions**: None

**Endpoint**:
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/vendors
```

**Purpose**: Access and manage vendor master data.

---

## Bound Actions Reference

Bound actions are operations that can be performed on specific entity records. The GM extension includes **3 bound actions** across **2 API pages**.

### 1. ManualReward (Loyalty Participants API)

**Purpose**: Manually award loyalty points to a loyalty participant.

**HTTP Method**: POST

**Endpoint**:
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants({systemId})/Microsoft.NAV.ManualReward
```

**Request Headers**:
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Request Body**:
```json
{}
```

**Response**: HTTP 200 OK with updated loyalty participant record

**Business Logic**:
1. Opens a transaction form dialog for manual point entry
2. Creates a new entry in the Loyalty Register table
3. Creates a new entry in the Loyalty Entry table with `Entry Type::Earned`
4. Posts general journal entries for loyalty accrual:
   - Debit: Loyalty Program Accrual Account
   - Credit: Loyalty Program Balance Account
   - Amount: Points × Point Value

**Example**:
```bash
curl -X POST \
  'https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants(12345678-abcd-1234-5678-123456789abc)/Microsoft.NAV.ManualReward' \
  -H 'Authorization: Bearer {token}' \
  -H 'Content-Type: application/json' \
  -d '{}'
```

---

### 2. Redemption (Loyalty Participants API)

**Purpose**: Process loyalty point redemption for a participant.

**HTTP Method**: POST

**Endpoint**:
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants({systemId})/Microsoft.NAV.Redemption
```

**Request Headers**:
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Request Body**:
```json
{}
```

**Response**: HTTP 200 OK with updated loyalty participant record

**Business Logic**:
1. Opens a transaction form dialog for redemption entry
2. Creates a new entry in the Loyalty Register table with negative points
3. Creates a new entry in the Loyalty Entry table with `Entry Type::Redeemed`
4. Posts general journal entries for loyalty redemption:
   - Debit: Loyalty Program Balance Account
   - Credit: Loyalty Program Accrual Account
   - Amount: Points × Point Value

**Example**:
```bash
curl -X POST \
  'https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants(12345678-abcd-1234-5678-123456789abc)/Microsoft.NAV.Redemption' \
  -H 'Authorization: Bearer {token}' \
  -H 'Content-Type: application/json' \
  -d '{}'
```

---

### 3. PostPurchaseOrderReceipt (Purchase Order Post API)

**Purpose**: Post a purchase order receipt without creating an invoice.

**HTTP Method**: POST

**Endpoint**:
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders({systemId})/Microsoft.NAV.PostPurchaseOrderReceipt
```

**Request Headers**:
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Request Body**:
```json
{}
```

**Response**: HTTP 200 OK (resource deleted as order is posted)

**Business Logic**:
1. Retrieves the purchase order by document type and number
2. Sets `Receive := true` (post receipt)
3. Sets `Invoice := false` (don't create invoice)
4. Posts the purchase order using the `Purch.-Post` codeunit
5. Updates inventory and creates posted receipt document

**Example**:
```bash
curl -X POST \
  'https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders(87654321-dcba-4321-8765-fedcba987654)/Microsoft.NAV.PostPurchaseOrderReceipt' \
  -H 'Authorization: Bearer {token}' \
  -H 'Content-Type: application/json' \
  -d '{}'
```

---

## Usage Examples

### Reading Data

**Get all loyalty participants**:
```http
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants
```

**Get a specific customer**:
```http
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers(12345678-abcd-1234-5678-123456789abc)
```

**Filter items by type**:
```http
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/items?$filter=type eq 'Inventory'
```

**Get top 10 customers ordered by name**:
```http
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers?$top=10&$orderby=name
```

### Creating Data

**Create a new loyalty comment**:
```http
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyComments
Content-Type: application/json

{
  "participantId": 12345,
  "date": "2024-12-04",
  "comment": "Customer inquiry about points balance"
}
```

### Updating Data

**Update customer email**:
```http
PATCH https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers(12345678-abcd-1234-5678-123456789abc)
Content-Type: application/json

{
  "email": "newemail@example.com"
}
```

### Executing Bound Actions

**Award loyalty points**:
```http
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants(12345678-abcd-1234-5678-123456789abc)/Microsoft.NAV.ManualReward
Content-Type: application/json

{}
```

**Post purchase receipt**:
```http
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders(87654321-dcba-4321-8765-fedcba987654)/Microsoft.NAV.PostPurchaseOrderReceipt
Content-Type: application/json

{}
```

## Authentication

All API calls require authentication. Business Central supports multiple authentication methods:

### OAuth 2.0 (Recommended for Cloud)

1. Register an application in Azure AD
2. Obtain an access token
3. Include the token in the Authorization header:
```
Authorization: Bearer {access_token}
```

### Web Services Access Key

For development and testing:
1. Generate a Web Services Access Key in Business Central
2. Use Basic Authentication:
```
Authorization: Basic {base64(username:access_key)}
```

### Example OAuth Token Request

```bash
curl -X POST \
  'https://login.microsoftonline.com/5f10a982-8c82-4eb2-92db-a0cd54b2f754/oauth2/v2.0/token' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'grant_type=client_credentials' \
  -d 'client_id={your_client_id}' \
  -d 'client_secret={your_client_secret}' \
  -d 'scope=https://api.businesscentral.dynamics.com/.default'
```

## Migration from SOAP Web Services

The bound actions in this API implementation replace the legacy SOAP web services from Microsoft Navision 5.0. Here's the migration mapping:

| Legacy SOAP Method | New API Bound Action | API Page |
|-------------------|---------------------|----------|
| `gFncManualReward` | ManualReward | Loyalty Participants API |
| `gFncRedemption` | Redemption | Loyalty Participants API |

**Key Differences**:
- **Protocol**: SOAP → OData v4 REST
- **Data Format**: XML → JSON
- **Authentication**: Windows Auth/NTLM → OAuth 2.0
- **Endpoint Structure**: Procedure-based → Resource-based with actions
- **Key Field**: Natural keys → SystemId (GUID)

**Migration Benefits**:
- Modern REST API standards
- Better security with OAuth 2.0
- JSON support for easier integration
- Standard OData query capabilities
- Better performance and scalability

## Summary

This GM Business Central extension provides **20 comprehensive API pages** with **3 bound actions** for managing:
- Customer and vendor data
- Items and inventory
- Sales and purchase documents
- Loyalty program participants and transactions
- Custom business entities (product groups, order statuses, etc.)

All APIs follow modern OData v4 standards and replace legacy SOAP-based web services with improved security, performance, and ease of integration.

For detailed technical documentation, see [src/API/README.md](src/API/README.md).
