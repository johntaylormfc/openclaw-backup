# Kick Connect Integration - BC Reports

This document describes the Kick Connect integration implemented in the BC (Business Central) versions of the import reports.

## Overview

Two new reports have been created that use the Kick Connect app for file operations:
- Report 65633: "Superfeeds Import BC" (based on 65631)
- Report 65634: "Promtek Import BC" (based on 65632)

## Kick Connect Dependency

The Kick Connect app has been added to the dependencies in `app.json`:
```json
{
  "id": "4f4c991d-b66e-418f-bfad-c800dabda51c",
  "name": "Kick Connect",
  "publisher": "Kick ICT",
  "version": "1.0.1.5"
}
```

## File Operations Using Kick Connect

The following file operations have been implemented using the `KICK File Management` codeunit:

### GetFileList
Retrieves a list of files from a specified directory with file pattern filtering.
```al
KickFileManagement.GetFileList(FilePath, '*.csv;*.txt;*.xml', FileNames)
```

### ReadTextFile
Reads the entire contents of a text file into a string variable.
```al
KickFileManagement.ReadTextFile(FileName, FileContent)
```

### MoveFile
Moves or renames a file from one location to another.
```al
KickFileManagement.MoveFile(OldFileName, NewFileName)
```

### ArchiveFile
Archives a processed file (Superfeeds Import BC only).
```al
KickFileManagement.ArchiveFile(FileName)
```

## Report Details

### Superfeeds Import BC (65633)
This report processes Superfeeds import files:
1. Gets list of files from the import folder
2. For each file:
   - Imports the data (CSV or XML format)
   - Archives the file
   - Moves/renames it to the export folder with timestamp
3. Processes the imported data to update BOM components and labels

**Key Changes from Original:**
- Replaced commented-out `File.Open()` and `File.Read()` with `KickFileManagement.ReadTextFile()`
- Replaced stub `GetFileList()` with actual Kick Connect implementation
- Replaced stub `ArchiveFile()` with actual Kick Connect implementation
- Replaced stub `RenameFile()` with `KickFileManagement.MoveFile()`

### Promtek Import BC (65634)
This report processes Promtek import files:
1. Gets list of files from the import folder
2. For each file:
   - Imports the data to Production Schedule Header and Lines
   - Moves the file to the Processed subfolder
3. Logs the import activity

**Key Changes from Original:**
- Replaced commented-out `File.Open()` and `File.Read()` with `KickFileManagement.ReadTextFile()`
- Replaced stub `GetFileList()` with actual Kick Connect implementation
- Replaced stub `RenameFile()` with `KickFileManagement.MoveFile()`

## Usage

These reports should be run manually or scheduled via job queue entries. They require:
- Inventory Setup with appropriate file paths configured
- Kick Connect app installed and configured in the environment
- Appropriate permissions to access the file paths

## Testing

To test the reports:
1. Ensure Kick Connect is properly installed and configured
2. Configure the file paths in Inventory Setup
3. Place test files in the import folders
4. Run the reports
5. Verify that files are processed and moved/archived correctly
6. Check that records are created in the appropriate tables
