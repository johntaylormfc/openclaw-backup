# What's Next - Action Items

## ✅ Completed by This PR

1. ✅ Created report extension 65620 for BC standard report 1306
2. ✅ Added 14 header fields from Sales Invoice Header Extension
3. ✅ Added 5 line fields from Sales Invoice Line Extension
4. ✅ Deleted old custom report 65620 (had errors)
5. ✅ Deleted old RDLC layout
6. ✅ Created comprehensive documentation suite
7. ✅ Created placeholder RDLC with instructions

## 🔄 Required Next Steps (User Action)

### Step 1: Deploy to BC (Required - 5 minutes)
**Who**: Developer with BC access  
**When**: Now  
**How**: 
1. Open GM extension in VS Code
2. Press F5 to publish
3. Verify deployment succeeds

**Success**: Extension appears in BC Extension Management

---

### Step 2: Export Standard Layout (Required - 10 minutes)
**Who**: BC Administrator or Developer  
**When**: After Step 1  
**How**:
1. Open BC Web Client
2. Search → "Report Layouts"
3. Find: Report 1306 "Standard Sales - Invoice"
4. Action: "Export Layout"
5. Choose: RDLC Layout
6. Save file for reference

**Success**: You have the standard RDLC file

---

### Step 3: Customize Layout (Required - 30-60 minutes)
**Who**: Report Designer (Visual Studio or Report Builder)  
**When**: After Step 2  
**How**:
1. Open exported RDLC in Visual Studio or SQL Report Builder
2. Modify layout to match NAV 5.0 format:
   - Adjust header layout
   - Modify fonts and styling
   - Adjust positioning
3. Add GM custom fields (see field list in docs)
4. Test layout in Report Builder preview
5. Save as: `StandardSalesInvoice.rdlc`
6. Copy to: `src/ReportExt/Layout/StandardSalesInvoice.rdlc`

**Success**: Custom layout matches NAV 5.0 requirements

---

### Step 4: Redeploy with Layout (Required - 5 minutes)
**Who**: Developer  
**When**: After Step 3  
**How**:
1. In VS Code, press F5 again
2. Wait for deployment
3. Check for any errors

**Success**: Extension with custom layout deployed

---

### Step 5: Test Report (Required - 15 minutes)
**Who**: QA or Business User  
**When**: After Step 4  
**How**:
1. Go to Posted Sales Invoices
2. Select a test invoice
3. Click: Print/Send → Preview
4. If not already selected, choose: "Standard Sales Invoice (GM)" layout
5. Verify:
   - Invoice displays correctly
   - Standard fields show data
   - GM custom fields show data (mobile numbers, loyalty, payments)
   - Format matches NAV 5.0
   - Totals are correct

**Success**: Report prints correctly with all fields

---

### Step 6: Set as Default (Optional - 2 minutes)
**Who**: BC Administrator  
**When**: After successful testing  
**How**:
1. Go to: Report Layouts
2. Find: Report 1306
3. Select: "Standard Sales Invoice (GM)"
4. Click: "Set Default"

**Success**: GM layout is default for all users

---

### Step 7: Update Report Selection (Optional - 5 minutes)
**Who**: BC Administrator  
**When**: After Step 6  
**How**:
1. Search → "Report Selection - Sales"
2. For "Invoice", verify Report 1306 is selected
3. No changes needed if already 1306

**Success**: Standard BC invoice workflow uses GM layout

---

## 📋 Testing Checklist

Before moving to production, test:

- [ ] Deploy extension without errors
- [ ] Layout appears in Report Layouts page
- [ ] Can preview invoice from Posted Sales Invoices
- [ ] Company logo displays
- [ ] Company information displays correctly
- [ ] Bill-to address formats correctly
- [ ] Ship-to address formats correctly
- [ ] Invoice header fields display
- [ ] Line items display correctly
- [ ] VAT summary is accurate
- [ ] Totals calculate correctly
- [ ] Mobile phone numbers display (custom field)
- [ ] Loyalty information displays (custom field)
- [ ] Payment amounts display (custom field)
- [ ] Format matches NAV 5.0 requirements
- [ ] Can print to PDF
- [ ] Can email invoice
- [ ] Multiple invoices batch print correctly
- [ ] Performance is acceptable

## 🚫 Important Notes

### Do NOT:
- ❌ Modify the report extension AL code (unless adding fields)
- ❌ Delete the table extensions (they provide the custom fields)
- ❌ Change the report extension ID (65620)
- ❌ Try to run report 65620 as custom report (it's deleted)

### DO:
- ✅ Keep the documentation in src/ReportExt/
- ✅ Back up your customized RDLC layout
- ✅ Test thoroughly before production use
- ✅ Train users on any layout changes
- ✅ Version control the RDLC file

## 🆘 If Something Goes Wrong

### Extension won't deploy
1. Check AL compiler errors in VS Code
2. Verify BC connection (check launch.json)
3. Check no conflicting object IDs
4. Try: Clean and rebuild

### Layout doesn't appear
1. Verify extension deployed successfully
2. Check RDLC file exists in correct location
3. Validate RDLC XML syntax
4. Try: Redeploy extension

### Fields don't display
1. Verify table extensions are deployed
2. Check field names match exactly (case-sensitive)
3. Ensure _GM suffix is used for extension fields
4. Test: View source data in tables

### Report shows errors
1. Check BC event log
2. Validate RDLC against dataset
3. Compare with standard 1306 behavior
4. Simplify: Remove custom fields to isolate issue

## 📞 Support

### Resources Available:
1. **StandardSalesInvoice.README.md** - Complete documentation
2. **IMPLEMENTATION_GUIDE.md** - Detailed steps
3. **SUMMARY.md** - Overview and changes
4. **QUICK_REFERENCE.md** - Quick guide

### Additional Help:
- Microsoft Docs: docs.microsoft.com/dynamics365/business-central
- BC Community: community.dynamics.com
- Report Layout Guide: Microsoft Report Builder documentation

## ✨ Expected Outcome

After completing all steps:

1. ✅ Report 1306 has GM custom layout available
2. ✅ Layout matches NAV 5.0 invoice format
3. ✅ All GM custom fields display correctly
4. ✅ Easier to maintain than old custom report
5. ✅ Automatically benefits from BC updates to report 1306
6. ✅ Can be set as default for all users

## 🎯 Success Criteria

**You'll know it's working when:**
- Users can print invoices from Posted Sales Invoices
- Invoice format matches NAV 5.0 requirements
- All custom fields (mobile, loyalty, payments) display
- No errors in BC event log
- Performance is acceptable
- Users are satisfied with the layout

## 📅 Recommended Timeline

- **Day 1**: Steps 1-2 (Deploy & Export) - 15 minutes
- **Day 2-3**: Step 3 (Customize Layout) - 1-2 hours
- **Day 3**: Steps 4-5 (Redeploy & Test) - 30 minutes
- **Day 4**: Additional testing - 1-2 hours
- **Day 5**: Steps 6-7 (Make Default) & Production - 30 minutes

**Total Effort**: 3-5 hours spread over a week for thorough testing

---

**Ready to start? Begin with Step 1: Deploy to BC**

See IMPLEMENTATION_GUIDE.md for detailed instructions on each step.
