# Sales Invoice GM Report Extension (65620)

## Overview
This report extension extends the standard Business Central Sales Invoice report (1306) with custom fields specific to Galloway & Macleod requirements. This approach leverages BC's standard invoice functionality while adding the necessary GM customizations.

## Report Details
- **Report Extension ID**: 65620
- **Report Extension Name**: Standard Sales Invoice GM
- **Extends**: Report 1306 "Standard Sales - Invoice"
- **Default Layout**: RDLC (Custom)

## Features

### Standard Fields (from Base Report 1306)
The report extension inherits all standard fields from BC Report 1306, including:
- Invoice Number, Order Number
- Posting Date, Due Date, Document Date, Shipment Date
- Bill-to Customer address
- Ship-to Address
- Salesperson information
- Shipment Method
- Line items with:
  - Item Number
  - Description
  - Quantity
  - Unit of Measure
  - Unit Price
  - Amount
- VAT breakdown
- Totals (Subtotal, VAT Amount, Invoice Total)

### Custom Fields Added by Extension
The report extension adds the following custom fields from the Sales Invoice Header and Line table extensions:

#### Header Extensions (Sales Invoice Header Ext - 65604)
- Ship-to Mobile No.
- Ship-to Mobile No. 2
- Old Ship-to Phone No.
- Loyalty Card No.
- Loyalty Points
- Cash, Cheque, Credit Card amounts
- Change
- Balance Due
- Deposit
- Write Off
- Customer PO
- Customer Reference

#### Line Extensions (Sales Invoice Line Ext - 65605)
- Loyalty Points
- Bonus Points
- Product Group Code
- Haulage
- Loyalty Discount

## RDLC Layout Setup

### Layout File Location
- Layout File: `./src/ReportExt/Layout/StandardSalesInvoice.rdlc`
- Layout Name: Standard Sales Invoice (GM)

### Important: Layout Configuration Required

**The RDLC layout file needs to be properly configured to match Report 1306's dataset structure.**

To set up the RDLC layout correctly:

1. **Option A: Export Standard Layout from BC (Recommended)**
   - Open Business Central Web Client
   - Navigate to "Report Layouts" page
   - Find Report 1306 "Standard Sales - Invoice"
   - Export the built-in RDLC layout
   - Save it as `StandardSalesInvoice.rdlc` in the `src/ReportExt/Layout/` directory
   - Modify the layout to:
     - Match NAV 5.0 invoice format (as per customer requirements)
     - Add references to the GM custom fields (suffixed with `_GM`):
       - `ShipToMobileNo_GM`
       - `LoyaltyCardNo_GM`
       - `Cash_GM`, `Cheque_GM`, `CreditCard_GM`
       - etc.

2. **Option B: Create Custom Layout**
   - Design a new RDLC layout using Visual Studio or Report Builder
   - Ensure it references the correct dataset columns from Report 1306
   - Add the GM extension columns where needed

### Dataset Column Names

The standard report 1306 columns plus the extension columns (with `_GM` suffix) can be used in the RDLC layout:

**Extension Columns (from Report Extension):**
- Header: `ShipToMobileNo_GM`, `ShipToMobileNo2_GM`, `OldShipToPhoneNo_GM`, `LoyaltyCardNo_GM`, `LoyaltyPoints_GM`, `Cash_GM`, `Cheque_GM`, `CreditCard_GM`, `Change_GM`, `BalanceDue_GM`, `Deposit_GM`, `WriteOff_GM`, `CustomerPO_GM`, `CustomerReference_GM`
- Line: `LoyaltyPoints_LineGM`, `BonusPoints_LineGM`, `ProductGroupCode_LineGM`, `Haulage_LineGM`, `LoyaltyDiscount_LineGM`

## Layout Features (To Be Implemented in RDLC)

### Header Section
- Company logo (from Company Information Picture field)
- Company name and contact information
- VAT Registration Number
- Invoice title

### Body Section
- Bill-to Customer address (left side)
- Ship-to Address (right side)
- Invoice details section showing:
  - Invoice Number
  - Order Number
  - Posting Date
  - Due Date
  - Shipment Date
  - Shipment Method
  - Salesperson

### Line Items Table
6-column table showing:
1. Item No.
2. Description
3. Quantity
4. Unit of Measure
5. Unit Price
6. Amount

### Footer Section
- VAT summary (VAT Base, VAT Amount, VAT Rate)
- Invoice Total
- Payment terms
- Company contact information and registration details

## Usage

### Running the Report
1. Navigate to Search and type "Standard Sales - Invoice"
2. Select Report 1306 from the list
3. The report will use the GM custom layout if it has been selected
4. Use the request page to filter by:
   - Invoice Number (No.)
   - Sell-to Customer No.
   - Posting Date
5. Click "Preview" to view or "Print" to generate

### Selecting the Custom Layout
1. Go to "Report Layouts" page in BC
2. Find Report 1306 "Standard Sales - Invoice"
3. Select the "Standard Sales Invoice (GM)" layout
4. Set it as default for the company/user if desired

## Technical Details

### Dataset Structure
The report extension adds columns to Report 1306's existing dataitems:
1. **Sales Invoice Header**: Extended with GM custom header fields
2. **Sales Invoice Line**: Extended with GM custom line fields

The base report 1306 already includes VAT and other standard dataitems.

### Report Extension File
- Location: `./src/ReportExt/StandardSalesInvoiceExt.ReportExt.al`
- Type: Report Extension
- Adds custom columns to existing dataitems
- Adds custom RDLC layout rendering

## Modifications from Standard BC Report 1306

This report extension adds GM-specific customizations to the standard BC Sales Invoice report:
1. **Custom fields from table extensions are exposed in the dataset**
   - Mobile phone numbers, loyalty information, payment details
2. **Custom RDLC layout designed to match NAV 5.0 format**
   - Layout must be configured as per instructions above
3. **Leverages BC standard functionality**
   - Address formatting, company information, VAT calculations
4. **Maintains compatibility with BC updates**
   - Since it's an extension, BC updates to report 1306 are inherited

### Advantages of Report Extension Approach

- **Less error-prone**: Leverages tested BC standard report logic
- **Easier maintenance**: BC handles standard fields and calculations
- **Better upgradability**: BC updates automatically apply
- **Familiar structure**: Uses BC's standard invoice format as base

## Migration from Report 65620

This report extension replaces the previous custom report 65620 "Sales Invoice GM". The key differences:

| Aspect | Old (65620) | New (Extension 65620) |
|--------|-------------|----------------------|
| Approach | Complete custom report | Extension of standard report |
| Base functionality | Custom implementation | Inherits from Report 1306 |
| Maintenance | High (all logic custom) | Low (only extensions) |
| BC updates | Manual updates needed | Automatic with BC |
| Dataset | Fully custom | Standard + extensions |

## Next Steps for Implementation

1. **Deploy the extension** to BC environment
2. **Export the standard RDLC layout** from Report 1306 in BC
3. **Modify the layout** to:
   - Match NAV 5.0 invoice design
   - Include GM custom fields (with `_GM` suffix)
   - Adjust formatting, fonts, and positioning as needed
4. **Upload the custom layout** back to BC for Report 1306
5. **Test thoroughly** with sample invoices
6. **Set as default layout** if testing is successful

## Future Enhancements

Potential improvements that could be made:
- Add support for multiple currencies
- Add item images/pictures
- Add barcode for invoice number
- Add electronic signature support
- Add payment instructions QR code
- Support for multiple languages

## Related Objects
- Report Extension 65620: Standard Sales Invoice GM (this extension)
- Table Extension 65604: Sales Invoice Header Ext
- Table Extension 65605: Sales Invoice Line Ext
- Report 1306: Standard Sales - Invoice (BC Standard - Extended by this)

## Notes
- The report extension follows BC standard patterns for extending reports
- Custom fields are added with `_GM` suffix to avoid naming conflicts
- The RDLC layout must be properly configured to display all fields
- Layout customization requires exporting and modifying the standard BC layout
- Test thoroughly after deployment to ensure all custom fields display correctly
