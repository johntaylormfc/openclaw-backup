# GM Extension API Pages

This directory contains API pages for the GM Business Central extension, enabling OData access to custom and standard Business Central entities.

## Overview

All APIs in this directory follow a consistent pattern:
- **API Publisher**: `bcdev`
- **API Group**: `operations`
- **API Version**: `v1.0`
- **OData Key**: `SystemId` (unique identifier for each record)
- **Delayed Insert**: Enabled for all APIs

### Base URL Format

All examples in this document use the following base URL structure:
```
https://api.businesscentral.dynamics.com/v2.0/{tenantId}/{environment}/api/bcdev/operations/v1.0/companies({companyId})/{entitySetName}
```

**Example Configuration:**
- **Tenant ID**: `5f10a982-8c82-4eb2-92db-a0cd54b2f754`
- **Environment**: `Sandbox`
- **Company ID**: `848fd9f3-6795-f011-b419-7c1e5279eaf3`

**Base URL:**
```
https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)
```

## Custom GM Table APIs

These APIs expose custom tables specific to the GM extension:

| API Page | Entity Name | Entity Set | Description | Bound Actions |
|----------|-------------|------------|-------------|---------------|
| ContactCommentsAPI | creditComment | creditComments | Credit control comment lines | None |
| LoyaltyCommentsAPI | loyaltyComment | loyaltyComments | Loyalty program comments | None |
| LoyaltyParticipantsAPI | loyaltyParticipant | loyaltyParticipants | Loyalty program participants | ManualReward, Redemption |
| OrderStatusAPI | orderStatus | orderStatuses | Order status codes | None |
| ProductGroupsAPI | productGroup | productGroups | Product group definitions | None |
| ProductionScheduleAPI | productionSchedule | productionSchedules | Production schedules | None |
| StrategyAPI | strategy | strategies | Strategy records for milk producers | None |

### Example URLs for Custom GM APIs

**Get all loyalty participants:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants
```

**Get a specific loyalty participant:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants({systemId})
```

**Get order statuses:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/orderStatuses
```

**Get loyalty comments:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyComments
```

**Get production schedules:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/productionSchedules
```

**Get product groups:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/productGroups
```

## Standard Business Central Table APIs

These APIs expose standard BC tables that have been extended in the GM extension:

| API Page | Entity Name | Entity Set | Description | Bound Actions |
|----------|-------------|------------|-------------|---------------|
| ContactAPI | contact | contacts | Contact records | None |
| CustomerAPI | customer | customers | Customer master data | None |
| ItemAPI | item | items | Item master data | None |
| PostedSalesCreditMemoAPI | postedSalesCreditMemo | postedSalesCreditMemos | Posted sales credit memos | None |
| PostedSalesInvoiceAPI | postedSalesInvoice | postedSalesInvoices | Posted sales invoices | None |
| PurchaseOrderPostAPI | purchaseOrder | purchaseOrders | Purchase orders | PostPurchaseOrderReceipt |
| PurchaseReturnOrderAPI | purchaseReturnOrder | purchaseReturnOrders | Purchase return orders | None |
| SalesInvoiceAPI | salesInvoice | salesInvoices | Sales invoices | None |
| SalesOrderAPI | salesOrder | salesOrders | Sales orders | None |
| SalesReturnOrderAPI | salesReturnOrder | salesReturnOrders | Sales return orders | None |
| SalespersonPurchaserAPI | salespersonPurchaser | salespersonPurchasers | Salesperson/Purchaser records | None |
| TransferOrderAPI | transferOrder | transferOrders | Transfer orders | None |
| VendorAPI | vendor | vendors | Vendor master data | None |

### Example URLs for Standard BC APIs

**Get all customers:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers
```

**Get a specific customer:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers({systemId})
```

**Get all items:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/items
```

**Get all vendors:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/vendors
```

**Get all purchase orders:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders
```

**Get all sales orders:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/salesOrders
```

**Get posted sales invoices:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/postedSalesInvoices
```

## Usage

### OData Endpoint Format

APIs are accessible via standard OData v4 endpoints:

```
https://api.businesscentral.dynamics.com/v2.0/{tenantId}/{environment}/api/bcdev/operations/v1.0/companies({companyId})/{entitySetName}
```

### Bound Actions

Bound actions are operations that can be performed on specific entity records. The GM extension includes the following bound actions:

#### 1. Loyalty Participants API - ManualReward

**Purpose:** Manually award loyalty points to a participant.

**Endpoint:**
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants({systemId})/Microsoft.NAV.ManualReward
```

**Headers:**
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Example Request:**
```http
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants(12345678-1234-1234-1234-123456789012)/Microsoft.NAV.ManualReward
Content-Type: application/json

{}
```

**Description:** 
This action opens a transaction form dialog to manually award loyalty points to the selected participant. The action creates entries in both the Loyalty Register and Loyalty Entry tables, and posts the corresponding general journal entries for the loyalty accrual.

#### 2. Loyalty Participants API - Redemption

**Purpose:** Process loyalty points redemption for a participant.

**Endpoint:**
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants({systemId})/Microsoft.NAV.Redemption
```

**Headers:**
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Example Request:**
```http
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyParticipants(12345678-1234-1234-1234-123456789012)/Microsoft.NAV.Redemption
Content-Type: application/json

{}
```

**Description:** 
This action opens a transaction form dialog to process redemption of loyalty points for the selected participant. Points are deducted from the participant's balance, and corresponding entries are created in the Loyalty Register and Loyalty Entry tables.

#### 3. Purchase Order Post API - PostPurchaseOrderReceipt

**Purpose:** Post a purchase order receipt without creating an invoice.

**Endpoint:**
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders({systemId})/Microsoft.NAV.PostPurchaseOrderReceipt
```

**Headers:**
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Example Request:**
```http
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/purchaseOrders(87654321-4321-4321-4321-210987654321)/Microsoft.NAV.PostPurchaseOrderReceipt
Content-Type: application/json

{}
```

**Description:** 
This action posts the purchase order receipt (goods received) without creating an invoice. The Receive flag is set to true and the Invoice flag is set to false before posting.

### Standard API Operations Examples

**Get all order statuses:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/orderStatuses
```

**Get a specific customer by SystemId:**
```
GET https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers(87654321-4321-4321-4321-210987654321)
```

**Create a new loyalty comment:**
```
POST https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/loyaltyComments
Content-Type: application/json

{
  "participantId": 12345,
  "date": "2024-10-04",
  "comment": "Customer inquiry about points balance"
}
```

**Update a customer:**
```
PATCH https://api.businesscentral.dynamics.com/v2.0/5f10a982-8c82-4eb2-92db-a0cd54b2f754/Sandbox/api/bcdev/operations/v1.0/companies(848fd9f3-6795-f011-b419-7c1e5279eaf3)/customers(87654321-4321-4321-4321-210987654321)
Content-Type: application/json

{
  "phoneNo": "+44 1234 567890",
  "email": "customer@example.com"
}
```

### OData Query Options

All APIs support standard OData query options:

- `$filter`: Filter results (e.g., `$filter=blocked eq false`)
- `$select`: Choose specific fields (e.g., `$select=number,name`)
- `$expand`: Include related data
- `$orderby`: Sort results (e.g., `$orderby=name asc`)
- `$top`: Limit number of results (e.g., `$top=10`)
- `$skip`: Skip results for pagination (e.g., `$skip=20`)
- `$count`: Get total count (e.g., `$count=true`)

### Authentication

APIs require authentication using:
- **OAuth 2.0**: For cloud deployments
- **Windows Authentication**: For on-premises deployments
- **Web Services Access Key**: For basic authentication

## Field Naming Conventions

Field names in the API use camelCase convention:
- BC Field: `"Customer No."` → API Field: `customerNo`
- BC Field: `"Post Code"` → API Field: `postCode`
- BC Field: `"E-Mail"` → API Field: `email`

## Notes

### Document Type Filtering

Some APIs automatically filter by document type:
- **SalesOrderAPI**: Filters to `Document Type::Order`
- **SalesInvoiceAPI**: Filters to `Document Type::Invoice`
- **SalesReturnOrderAPI**: Filters to `Document Type::"Return Order"`
- **PurchaseOrderPostAPI**: Filters to `Document Type::Order`
- **PurchaseReturnOrderAPI**: Filters to `Document Type::"Return Order"`

### SystemId vs Natural Keys

All APIs use `SystemId` as the OData key field. This is a GUID that uniquely identifies each record across the system. While you can filter by natural keys (like customer number), the SystemId should be used for direct record access.

### Extensibility

To extend these APIs:
1. Field additions in source tables automatically appear in the API
2. New calculated fields can be added to the API page
3. Additional filtering can be added in `OnOpenPage` triggers
4. Custom actions can be added using `[ServiceEnabled]` procedures

## Support

For issues or questions about these APIs, please contact the development team or open an issue in the repository.
