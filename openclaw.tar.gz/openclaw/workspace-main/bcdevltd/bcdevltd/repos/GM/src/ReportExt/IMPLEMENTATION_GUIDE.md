# Step-by-Step Implementation Guide for Sales Invoice Report Extension

## Overview
This guide provides detailed steps to complete the Sales Invoice report extension implementation. The report extension (65620) has been created and adds custom GM fields to the standard BC Sales Invoice report (1306).

## Current Status
✅ Report extension created (`StandardSalesInvoiceExt.ReportExt.al`)  
✅ Custom fields added to dataset  
✅ Old custom report (65620) deleted  
✅ Documentation updated  
⏳ **NEXT: RDLC layout needs to be configured**

## Steps to Complete Implementation

### Step 1: Deploy the Report Extension to BC

1. Open the GM extension in Visual Studio Code
2. Press F5 or use "AL: Publish" command
3. Wait for the extension to deploy to your BC sandbox/environment
4. Verify deployment by checking for any compilation errors

### Step 2: Export the Standard Report 1306 Layout

**Option A: From BC Web Client (Recommended)**

1. Open Business Central Web Client
2. Search for "Report Layouts"  
3. Find **Report 1306 - Standard Sales - Invoice**
4. Click on the row, then choose "Export Layout"
5. Select "RDLC Layout" if prompted
6. Save the file as `StandardSalesInvoice_Original.rdlc` (for reference)

**Option B: From BC Designer (Alternative)**

1. In BC Web Client, search for "Report Selection - Sales"
2. For "Invoice", note the current report (should be 1306)
3. Use Report Inspector (Ctrl+Alt+F1) to view report details
4. Use "Download Layout" option if available

### Step 3: Understand the Standard Layout Dataset

After exporting, open the RDLC in a text editor and note the dataset structure:

- Look for `<DataSet Name="DataSet_Result">` section
- Note the `<Field Name="...">` entries
- Common fields you'll find:
  - Header fields: `No_`, `SelltoCustomerName`, `PostingDate`, etc.
  - Line fields: `ItemNo`, `Description`, `Quantity`, `UnitPrice`, etc.
  - Calculated fields: Various totals and labels

### Step 4: Modify the Layout for GM Requirements

1. Open the exported RDLC in **Visual Studio** or **SQL Server Report Builder**
2. Add the GM extension fields to the dataset (they should already be available):
   
   **Header Fields (with _GM suffix):**
   - `ShipToMobileNo_GM`
   - `ShipToMobileNo2_GM`
   - `OldShipToPhoneNo_GM`
   - `LoyaltyCardNo_GM`
   - `LoyaltyPoints_GM`
   - `Cash_GM`
   - `Cheque_GM`
   - `CreditCard_GM`
   - `Change_GM`
   - `BalanceDue_GM`
   - `Deposit_GM`
   - `WriteOff_GM`
   - `CustomerPO_GM`
   - `CustomerReference_GM`
   
   **Line Fields (with _LineGM suffix):**
   - `LoyaltyPoints_LineGM`
   - `BonusPoints_LineGM`
   - `ProductGroupCode_LineGM`
   - `Haulage_LineGM`
   - `LoyaltyDiscount_LineGM`

3. Modify the layout design to match **NAV 5.0 invoice format**:
   - Adjust header positioning
   - Add/modify textboxes for GM custom fields
   - Update footer with payment information (Cash, Cheque, Credit Card)
   - Adjust fonts, colors, and spacing as needed
   - Add loyalty information section if required

4. Save the modified layout as `StandardSalesInvoice.rdlc`

5. Copy the file to: `./src/ReportExt/Layout/StandardSalesInvoice.rdlc` in your extension source

### Step 5: Deploy Updated Extension with Custom Layout

1. In VS Code, deploy the extension again (F5)
2. The custom RDLC layout should now be available in BC

### Step 6: Configure the Layout in BC

1. In BC Web Client, go to "Report Layouts"
2. Find Report 1306
3. You should now see "Standard Sales Invoice (GM)" as an available layout
4. Select it and click "Set Default" if desired
5. Alternatively, users can select it per-report run

### Step 7: Test the Report

1. Navigate to **Posted Sales Invoices**
2. Select a test invoice
3. Click "Print/Send" → "Preview"
4. Choose Report 1306 with the GM layout
5. Verify:
   - Standard fields display correctly
   - GM custom fields (mobile numbers, loyalty info) display correctly
   - Format matches NAV 5.0 expectations
   - Totals calculate correctly
   - VAT information is accurate

### Step 8: Troubleshooting

**If fields don't appear:**
- Check that the extension deployed successfully
- Verify field names match exactly (case-sensitive, including _GM suffix)
- Check that table extensions are applied
- Restart BC service if needed

**If layout errors occur:**
- Validate the RDLC XML structure
- Check for unclosed tags or syntax errors
- Ensure dataset field references are correct
- Test with Report Builder's preview feature first

**If data is incorrect:**
- Verify source data in tables (Sales Invoice Header/Line)
- Check table extension field values
- Ensure filters are applied correctly

## Alternative Approach: Create Layout from Scratch

If you prefer to create a completely custom layout:

1. Create a blank RDLC in Report Builder
2. Connect to the BC dataset for Report 1306
3. Design the layout from scratch using the NAV 5.0 format as reference
4. Add all required fields (standard + GM extensions)
5. Save and deploy as above

## Reference: Old vs New Field Mapping

For reference, here's how old custom report fields map to the new extension:

| Old Report 65620 Field | New Extension Field | Notes |
|------------------------|---------------------|-------|
| ShipToMobileNo | ShipToMobileNo_GM | Now with _GM suffix |
| LoyaltyCardNo | LoyaltyCardNo_GM | Now with _GM suffix |
| Cash | Cash_GM | Now with _GM suffix |
| No_ | (Standard) | Inherited from 1306 |
| PostingDate | (Standard) | Inherited from 1306 |
| LineItemNo | (Standard) | Inherited from 1306 |
| LineDescription | (Standard) | Inherited from 1306 |

## Support and Questions

If you encounter issues:
1. Check the AL extension compiled without errors
2. Verify the RDLC XML is valid
3. Review the BC event log for errors
4. Test with a simple invoice first
5. Compare with the standard 1306 layout behavior

## Success Criteria

✅ Extension deploys without errors  
✅ Layout displays in BC Report Layouts page  
✅ Invoice preview works without errors  
✅ All standard fields display correctly  
✅ All GM custom fields display correctly  
✅ Format matches NAV 5.0 requirements  
✅ Can be set as default layout  
