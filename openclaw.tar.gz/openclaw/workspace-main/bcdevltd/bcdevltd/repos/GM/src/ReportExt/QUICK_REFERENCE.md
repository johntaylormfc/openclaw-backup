# Sales Invoice Report Extension - Quick Reference

## Overview
Report extension 65620 extends BC standard report 1306 "Standard Sales - Invoice" with GM custom fields.

## Files Created

```
src/ReportExt/
├── StandardSalesInvoiceExt.ReportExt.al  ← Report extension code
├── StandardSalesInvoice.README.md         ← Full documentation
├── IMPLEMENTATION_GUIDE.md                ← Step-by-step instructions
├── SUMMARY.md                             ← Detailed summary
├── QUICK_REFERENCE.md                     ← This file
└── Layout/
    └── StandardSalesInvoice.rdlc          ← RDLC layout (placeholder)
```

## Files Deleted
- `src/Report/SalesInvoice.Report.al` (old custom report)
- `src/Report/Layout/SalesInvoice.rdlc` (old layout)
- `src/Report/SalesInvoice.README.md` (old documentation)

## Quick Start

### 1. Deploy (5 minutes)
```
1. Open VS Code
2. Press F5
3. Wait for deployment
```

### 2. Export Layout (10 minutes)
```
1. Open BC Web Client
2. Search "Report Layouts"
3. Find Report 1306
4. Click "Export Layout"
5. Save file
```

### 3. Customize Layout (30-60 minutes)
```
1. Open RDLC in Visual Studio/Report Builder
2. Adjust to match NAV 5.0 format
3. Add GM fields (see list below)
4. Save as StandardSalesInvoice.rdlc
5. Copy to src/ReportExt/Layout/
```

### 4. Redeploy & Test (10 minutes)
```
1. Press F5 again in VS Code
2. Test from Posted Sales Invoices
3. Verify fields display correctly
```

## GM Custom Fields Added

### Header Fields (prefix with _GM in RDLC)
- ShipToMobileNo_GM
- ShipToMobileNo2_GM
- OldShipToPhoneNo_GM
- LoyaltyCardNo_GM
- LoyaltyPoints_GM
- Cash_GM
- Cheque_GM
- CreditCard_GM
- Change_GM
- BalanceDue_GM
- Deposit_GM
- WriteOff_GM
- CustomerPO_GM
- CustomerReference_GM

### Line Fields (prefix with _LineGM in RDLC)
- LoyaltyPoints_LineGM
- BonusPoints_LineGM
- ProductGroupCode_LineGM
- Haulage_LineGM
- LoyaltyDiscount_LineGM

## Usage in BC

### Running the Report
1. Go to Posted Sales Invoices
2. Select an invoice
3. Click Print/Send → Preview
4. Report 1306 runs with GM layout (if set as default)

### Setting as Default
1. Go to Report Layouts
2. Find Report 1306
3. Select "Standard Sales Invoice (GM)"
4. Click "Set Default"

## Key Differences from Old Report

| Feature | Old (Custom) | New (Extension) |
|---------|--------------|-----------------|
| Object Type | Report 65620 | Report Extension 65620 |
| Base | Custom | Extends Report 1306 |
| Maintenance | High | Low |
| BC Updates | Manual | Automatic |
| Stability | Issues reported | BC standard + extensions |

## Troubleshooting

### Extension won't deploy
- Check for syntax errors in AL file
- Verify ID 65620 isn't conflicting
- Check BC connection

### Layout doesn't appear
- Ensure extension deployed successfully
- Check RDLC file is in correct location
- Verify RDLC syntax is valid

### Fields don't display
- Check field names match exactly
- Ensure _GM suffix is used
- Verify table extensions are applied

### Data is missing
- Check source table has data
- Verify table extension fields populated
- Test with different invoice

## Support Resources

- **Full Documentation**: StandardSalesInvoice.README.md
- **Step-by-Step Guide**: IMPLEMENTATION_GUIDE.md
- **Detailed Summary**: SUMMARY.md
- **BC Documentation**: docs.microsoft.com/dynamics365/business-central

## Contacts

If issues persist:
1. Check AL compiler output
2. Review BC event log
3. Compare with standard 1306 behavior
4. Contact BC support for platform issues

## Version Info

- **Version**: 1.0
- **Created**: 2024
- **BC Version**: 26.0 (compatible with 25.0+)
- **Status**: Ready for deployment (RDLC needs customization)

## Next Action Required

**→ Export and customize the RDLC layout from BC Report 1306**

See IMPLEMENTATION_GUIDE.md for detailed instructions.
