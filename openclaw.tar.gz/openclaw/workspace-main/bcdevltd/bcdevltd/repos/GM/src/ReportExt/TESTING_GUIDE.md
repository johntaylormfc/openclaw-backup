# Testing Guide for Converted RDLC Layout

## What Was Done

The issue requested to use `OriginalStandardSalesInvoice.rdlc` as the basis for the new layout instead of creating one from scratch. This has been completed:

1. ✅ Fixed `OriginalStandardSalesInvoice.rdlc` (was malformed XML)
2. ✅ Copied it to `StandardSalesInvoice.rdlc` 
3. ✅ Added all 19 GM custom fields to the dataset
4. ✅ Validated the XML structure

## Current Status

Both RDLC files are now:
- **Valid XML** (verified with parser)
- **931 lines** each (reduced from 2,791 for Standard and 946 for Original)
- **Identical** content
- **Complete dataset** with 59 fields (40 standard + 19 GM custom)
- **Functional layout** with all standard invoice sections

## How to Test

### Step 1: Deploy the Extension
```bash
# In VS Code
Press F5 to deploy to Business Central
```

### Step 2: Test the Layout
1. Open Business Central Web Client
2. Navigate to **Posted Sales Invoices**
3. Select any posted invoice
4. Click **Print/Send** → **Preview**
5. Select layout: **Standard Sales Invoice (GM)**
6. Click **Preview**

### Step 3: Verify Results

#### Expected Outcome:
✅ Invoice displays without errors
✅ Company logo appears (if configured)
✅ Company information displays
✅ Bill-To and Ship-To addresses show correctly
✅ Invoice details (number, date, etc.) display
✅ Line items table shows all items with:
   - Item No.
   - Description
   - Quantity
   - Unit of Measure
   - Unit Price
   - Amount
✅ Totals section shows subtotal, VAT, and total
✅ Footer displays company info

#### Possible Issues:

❌ **If layout doesn't appear in list:**
   - Redeploy extension
   - Check Report Layouts page for errors
   - Verify extension is published

❌ **If fields show as blank:**
   - This is normal if test invoice has no data for those fields
   - Try with an invoice that has complete data

❌ **If error occurs:**
   - Check error message
   - Verify dataset field names match Report Extension 65620
   - Check BC event log for details

## Customizing the Layout (Optional)

The current layout is functional but basic. To match the NAV 5.0 screenshot exactly:

### Option 1: Using Report Layouts in Business Central
1. Go to **Report Layouts** page
2. Find **Report 1306 - Standard Sales - Invoice**
3. Select the **Standard Sales Invoice (GM)** layout
4. Click **Export Layout**
5. Open in SQL Server Report Builder or Visual Studio
6. Make desired changes
7. Save and import back via **Import Layout**

### Option 2: Edit File Directly
1. Open `src/ReportExt/Layout/StandardSalesInvoice.rdlc` in Visual Studio
2. Use the Report Designer interface
3. Modify positioning, fonts, colors, borders as needed
4. Save changes
5. Redeploy extension (F5)

### Adding GM Custom Fields to Visual Layout

The GM fields are in the dataset but not yet placed on the layout. To add them:

1. Open RDLC in Report Builder/Visual Studio
2. In Report Data pane, expand DataSet_Result
3. Drag desired fields to the layout:

**Suggested Placements:**
- **Mobile Numbers**: Below Ship-To Address box
  - ShipToMobileNo_GM
  - ShipToMobileNo2_GM
  
- **Loyalty Info**: In Invoice Details section
  - LoyaltyCardNo_GM
  - LoyaltyPoints_GM
  
- **Payment Info**: Near Totals box
  - Cash_GM
  - Cheque_GM
  - CreditCard_GM
  - Change_GM
  - BalanceDue_GM
  - Deposit_GM
  
- **References**: In Invoice Details
  - CustomerPO_GM
  - CustomerReference_GM

4. Format the fields as needed (font, alignment, borders)
5. Save and test

## Layout Comparison

### Before (Issue #34):
- StandardSalesInvoice.rdlc: **2,791 lines** (created from scratch)
- Had errors (per issue description)
- Complex implementation

### After (This Fix):
- StandardSalesInvoice.rdlc: **931 lines** (based on Original)
- Valid XML structure
- Simplified, functional layout
- All GM fields in dataset

## File Locations

```
src/ReportExt/
├── StandardSalesInvoiceGM.ReportExt.al    (Report Extension 65620)
├── Layout/
│   ├── StandardSalesInvoice.rdlc          (Active layout - 931 lines)
│   └── OriginalStandardSalesInvoice.rdlc  (Backup/reference - 931 lines)
└── LAYOUT_CONVERSION_SUMMARY.md           (Detailed documentation)
```

## Troubleshooting

### Issue: "Field not found" error
**Cause**: Dataset field name mismatch
**Fix**: Verify field names in RDLC match the Report Extension (check for _GM suffix)

### Issue: Layout looks different from NAV 5.0
**Cause**: The current layout is a basic BC template
**Fix**: Customize using Report Builder (see "Customizing the Layout" above)

### Issue: GM fields don't show data
**Cause**: Fields are in dataset but not placed on visual layout
**Fix**: Add them manually using Report Builder (see "Adding GM Custom Fields" above)

## Success Criteria

The conversion is successful if:
- ✅ Extension deploys without errors
- ✅ Layout appears in report selection
- ✅ Invoice preview works
- ✅ No runtime errors occur
- ✅ Standard fields display correctly

## Next Steps

1. **Test the current layout** (follow Step 1-3 above)
2. **If it works**: Decide if customization is needed
3. **If customization needed**: Use Report Builder to adjust
4. **Add GM fields**: Follow the guide above to add custom fields to the visual layout
5. **Final testing**: Test with various invoices to ensure all scenarios work

## Questions?

If issues arise:
1. Check the BC event log for detailed errors
2. Verify Report Extension 65620 compiled successfully
3. Compare dataset field names between .al file and .rdlc file
4. Review LAYOUT_CONVERSION_SUMMARY.md for technical details

---

**Status**: ✅ Ready for testing in Business Central
