# GM Business Central Extension Overview

## Summary

Extension providing GM-specific functionality including loyalty programs, pricing, inventory management, and business operations 

## Functionality

- **Description**: Extension providing GM-specific functionality including loyalty programs, pricing, inventory management, and business operations
- **Publisher**: Galloway & Macleod
- **Integration Points**: External API Integration
- **Table**: Superfeeds
- **Table**: Superfeed
- **Table**: table 65600 Strategy
- **Table**: Shipment
- **Table**: Production
- **Table**: Product
- **Table**: Prod.

Generated on 2026-02-06