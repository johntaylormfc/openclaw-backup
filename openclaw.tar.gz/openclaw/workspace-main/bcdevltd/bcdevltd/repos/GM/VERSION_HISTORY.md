# Version History

This document tracks all versions of the GM Business Central Extension following semantic versioning (MAJOR.MINOR.PATCH).

## [1.1.0] - 2025-11-11

### Added
- Enhanced error handling for API endpoints with proper ErrorInfo implementation
- Comprehensive validation for Loyalty Participants API actions
- Detailed error messages with titles and descriptions

### Changed
- Updated from version 1.0.0.2 to semantic versioning format 1.1.0
- Improved API error responses for better client integration

### Technical Improvements
- Added validation procedures for ManualReward and Redemption actions
- Implemented proper label constants with comments for internationalization
- Enhanced API action response handling

## [1.0.0.2] - Previous Version

### Features
- Loyalty program management
- Credit control functionality  
- Production scheduling
- Extensive API coverage (20+ endpoints)
- Agricultural/dairy industry specific features

---

## Versioning Strategy

We follow [Semantic Versioning](https://semver.org/):

- **MAJOR**: Incompatible API changes or breaking changes
- **MINOR**: New functionality added in a backward-compatible manner
- **PATCH**: Backward-compatible bug fixes

### Breaking Change Policy
- Breaking changes will only be introduced in major versions
- Deprecation notices will be provided for at least one minor version before removal
- API versioning will be maintained for backward compatibility