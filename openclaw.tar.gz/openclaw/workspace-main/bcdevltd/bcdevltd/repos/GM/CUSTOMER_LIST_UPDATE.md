# Customer List Extension Update

## Summary
Updated `CustomerListExt.PageExt.al` to add fields from Microsoft Dynamics NAV 5.0 Form 22 (Customer List) that were missing from the Business Central Page 22 extension.

## Background
Microsoft Dynamics NAV 5.0 Form 22 (Customer List) contained various fields for displaying customer information in a list format. During the migration to Business Central, some of these fields needed to be added to the page extension to maintain feature parity.

## Changes Made

### File Modified
- `src/PageExt/CustomerListExt.PageExt.al`

### Fields Added (22 new fields)

#### 1. Financial FlowFields
Added key financial metrics that are commonly used in customer list views:

| Field Name | Visibility | Description |
|------------|-----------|-------------|
| Balance (LCY) | Visible | Current customer balance in local currency |
| Balance Due (LCY) | Visible | Overdue balance amount |
| Sales (LCY) | Hidden | Total sales amount for the customer |
| Payments (LCY) | Hidden | Total payments from the customer |
| Outstanding Orders (LCY) | Hidden | Outstanding sales order amount |
| Shipped Not Invoiced (LCY) | Hidden | Shipped but not yet invoiced amount |
| Outstanding Invoices (LCY) | Hidden | Outstanding invoice amount |

#### 2. Customer Information Fields
Added for better customer identification and searching:

| Field Name | Visibility | Description |
|------------|-----------|-------------|
| Search Name | Visible | Alternate name for searching customers |
| Post Code | Visible | Postal code/ZIP code |

#### 3. Business Setup Fields
Added for accounting and tax configuration visibility:

| Field Name | Visibility | Description |
|------------|-----------|-------------|
| Customer Posting Group | Hidden | Customer posting group code |
| Gen. Bus. Posting Group | Hidden | General business posting group |
| VAT Bus. Posting Group | Hidden | VAT business posting group |
| Credit Limit (LCY) | Visible | Maximum credit limit in local currency |

#### 4. Credit and Payment Management Fields
Added for better credit control and payment tracking:

| Field Name | Visibility | Description |
|------------|-----------|-------------|
| Credit Controller | Hidden | Assigned credit controller |
| Fin. Charge Terms Code | Hidden | Finance charge terms |
| Currency Code | Hidden | Customer's currency code |
| Blocked | Hidden | Blocked status indicator |
| Application Method | Hidden | Payment application method |

#### 5. Custom GM Fields
Added loyalty and legacy system fields:

| Field Name | Visibility | Description |
|------------|-----------|-------------|
| Loyalty Points | Hidden | Loyalty program points balance |
| Loyalty Balance | Hidden | Loyalty program balance |
| AS400 No. | Hidden | Legacy AS400 system number |
| Date Created | Hidden | Date when customer record was created |

### Code Changes

#### OnAfterGetRecord Trigger Enhancement
Updated the trigger to calculate all FlowFields for optimal performance:

```al
trigger OnAfterGetRecord()
begin
    // Calculate standard Customer table FlowFields
    Rec.CALCFIELDS("Balance (LCY)", "Balance Due (LCY)", "Sales (LCY)", "Payments (LCY)",
                   "Outstanding Orders (LCY)", "Shipped Not Invoiced (LCY)", "Outstanding Invoices (LCY)");
    
    // Calculate custom FlowFields
    Rec.CALCFIELDS("Loyalty Points", "Loyalty Balance", "LP24 Points", 
                   "Last Payment Date", "Last Invoice Date");

    // Legacy code for payment ledger entry (retained)
    CustLedgerEntry.RESET;
    CustLedgerEntry.SETCURRENTKEY("Customer No.", "Posting Date", "Document Type");
    CustLedgerEntry.SETRANGE("Customer No.", Rec."No.");
    CustLedgerEntry.SETFILTER("Document Type", '=%1', CustLedgerEntry."Document Type"::Payment);
    IF NOT CustLedgerEntry.FINDLAST THEN
        CustLedgerEntry.Amount := 0
    ELSE
        CustLedgerEntry.CALCFIELDS(Amount);
end;
```

## Field Placement Strategy

Fields were strategically placed after related standard fields to maintain logical grouping:

- **After Name**: Custom fields like Accounts E-Mail, Invoices Sent By, Loyalty fields
- **After Location Code**: Financial FlowFields (Balance, Sales, Payments, etc.)
- **After Contact**: Search Name and Post Code for better customer identification
- **After Responsibility Center**: Business setup and credit control fields
- **After Phone No.**: Mobile No. (already existed)
- **After Salesperson Code**: Shipment Method Code (already existed)
- **After Payment Terms Code**: Payment Method Code, Fin. Charge Terms, Currency Code
- **After Language Code**: Blocked, Application Method, Vehicle Access, etc.

## Design Decisions

### Hidden vs. Visible Fields
- **Visible by default**: Fields that are commonly used for quick reference (Balance, Balance Due, Credit Limit, etc.)
- **Hidden by default**: Advanced fields that are only needed occasionally (Posting Groups, Blocked status, etc.)

Users can easily personalize the page to show/hide fields based on their needs using Business Central's built-in personalization features.

### Field Positioning
Fields were added using `addafter` directives to place them near related standard Business Central fields, making the page extension intuitive and maintaining a logical flow.

### FlowField Calculation
All FlowFields are calculated in the `OnAfterGetRecord` trigger to ensure data is up-to-date when the page loads. This approach balances performance with data accuracy.

## Compatibility Notes

- All fields use existing Customer table fields (standard BC or GM extension)
- No new table fields were added
- Compatible with Business Central version 26.0 (as specified in app.json)
- Follows AL coding standards and best practices
- Extension ID range: 65600-65699 (as per app.json)

## Testing Recommendations

1. **Functional Testing**
   - Open Customer List page (Page 22)
   - Verify all new fields display correctly
   - Test field calculations with sample customer data
   - Verify FlowField values are accurate

2. **Personalization Testing**
   - Test showing/hiding fields through page personalization
   - Verify personalization settings persist across sessions
   - Test field ordering and grouping

3. **Performance Testing**
   - Test page load time with large customer datasets
   - Verify FlowField calculations don't cause performance issues
   - Monitor for any timeout issues with calculated fields

4. **Integration Testing**
   - Verify fields update correctly when customer data changes
   - Test with different user roles and permissions
   - Verify field visibility respects ApplicationArea settings

## Migration Notes

This extension bridges the gap between Microsoft Dynamics NAV 5.0 Form 22 and Business Central Page 22, ensuring that users migrating from NAV have access to familiar fields and functionality.

### Fields Not Added
The following types of fields were intentionally not added:
- Segment fields (Segment 1-19): These are very specific business fields and can be added separately if needed
- Fields that don't exist in the Customer table or its extension
- Deprecated or obsolete NAV fields that have been replaced in Business Central

## Future Enhancements

Potential future improvements could include:
1. Adding filtered views for specific customer categories
2. Adding segment fields if business requirements dictate
3. Adding additional loyalty program fields as the program evolves
4. Custom actions for common customer operations

## Support

For issues or questions about this update:
1. Check that all referenced fields exist in the Customer table and CustomerExt table extension
2. Verify Business Central version compatibility
3. Review AL compilation errors carefully for field name mismatches
4. Consult Business Central documentation for field-specific behavior

## Conclusion

This update provides comprehensive visibility into customer data from the Customer List page, matching the functionality available in NAV 5.0 Form 22 while taking advantage of Business Central's modern page extension capabilities.
