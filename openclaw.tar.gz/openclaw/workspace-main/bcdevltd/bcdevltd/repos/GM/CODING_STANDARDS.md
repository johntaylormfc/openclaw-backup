# AL Coding Standards for GM Business Central Extension

## Overview
This document outlines the coding standards and style guidelines for AL (Application Language) development in the GM Business Central extension.

## Language Standards

### Keywords
- All AL keywords must be written in **lowercase**
  - `begin`, `end`, `if`, `then`, `else`, `while`, `repeat`, `until`, `for`, `to`, `downto`, `do`, `case`, `of`, `with`

### Method Calls
- All method calls must use **PascalCase**
  - `SetRange()`, `SetFilter()`, `FindFirst()`, `FindLast()`, `Insert()`, `Modify()`, `Delete()`, `Clear()`, `TestField()`, `Validate()`

## Formatting Standards

### Indentation
- Use **4 spaces** for indentation (not tabs)
- Consistent indentation throughout all code blocks

### Naming Conventions
- **Objects**: PascalCase (e.g., `CustomerCard`, `SalesOrderList`)
- **Variables**: camelCase (e.g., `customerNo`, `salesAmount`)
- **Procedures/Functions**: PascalCase (e.g., `CalculateTotal()`, `ValidateData()`)
- **Constants**: UPPER_CASE (e.g., `MAX_LENGTH`)

### Code Structure
- Use `begin`/`end` blocks consistently
- Proper alignment of code elements
- Clear separation of logical sections

## Documentation Standards

### Comments
- Use `//` for single-line comments
- Use `/* */` for multi-line comments
- Document complex business logic
- Include parameter descriptions for public procedures

### XML Documentation
- Use triple-slash comments for public APIs
- Include summary, parameters, and return value descriptions

## Best Practices

### Performance
- Use appropriate filters to limit data access
- Avoid nested loops where possible
- Use `FindSet()` instead of `Find()` when iterating

### Error Handling
- Implement proper error handling with `if` statements
- Use `TestField()` for required field validation
- Provide meaningful error messages

### Security
- Validate user input
- Use appropriate permissions
- Avoid direct table access where possible

## Code Quality

### Compilation
- All code must compile without errors
- Resolve all warnings where possible

### Testing
- Unit tests for business logic
- Integration tests for workflows
- Manual testing for UI components

### Maintenance
- Keep code modular and reusable
- Avoid hard-coded values
- Use setup tables for configuration

## Tools and Automation

### AL Language Extension
- Use VS Code AL Language extension for development
- Enable auto-formatting on save
- Use IntelliSense for code completion

### Version Control
- Commit frequently with descriptive messages
- Use feature branches for development
- Review code changes before merging

## Compliance

All code in the GM extension must adhere to these standards. Automated tools will be used to enforce keyword casing and formatting rules. Manual reviews will ensure compliance with naming conventions and best practices.

## Version History

- v1.0 - Initial standards document (October 2025)
- Covers modern AL syntax requirements