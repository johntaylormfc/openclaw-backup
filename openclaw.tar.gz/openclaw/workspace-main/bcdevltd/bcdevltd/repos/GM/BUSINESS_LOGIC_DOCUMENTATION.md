# GM Business Logic Documentation

## Overview
This document provides detailed explanations of the complex business logic implemented in the GM Business Central extension, focusing on loyalty programs, sales processing, and agricultural industry-specific requirements.

## Loyalty Program System

### Core Concepts

#### Loyalty Participants
- **Purpose**: Manages customer participation in loyalty programs
- **Key Fields**:
  - `ID`: Unique participant identifier
  - `Customer No.`: Links to Business Central customer
  - `Card No.`: Physical or digital loyalty card number
  - `Status`: Active/Inactive state
  - `Blocked`: Prevents transactions when true
  - `Closed`: Permanently closes participant account

#### Point Calculation Logic
```al
// Points are calculated based on purchase amount
// Formula: Purchase Amount × Points per Pound = Total Points
// Subject to minimum transaction amount and maximum points per transaction
```

### Business Rules

#### Manual Reward Processing
1. **Validation Checks** (in order):
   - Participant must not be blocked
   - Participant account must not be closed  
   - Participant must be linked to a valid customer
   
2. **Processing Flow**:
   - Validate participant eligibility
   - Create loyalty entry with manual reward points
   - Update participant balance
   - Log transaction for audit trail

#### Redemption Processing
1. **Validation Checks** (same as manual reward):
   - Participant must not be blocked
   - Participant account must not be closed
   - Participant must be linked to a valid customer
   
2. **Additional Checks**:
   - Sufficient point balance for redemption
   - Redemption amount within allowed limits
   
3. **Processing Flow**:
   - Validate participant eligibility and balance
   - Deduct points from participant balance
   - Create redemption entry
   - Update customer account with credit/discount

## Sales Processing Logic

### Document Validation Rules

#### Sales Orders
The system enforces specific validation rules during sales order processing:

1. **Credit Control Validation**:
   ```al
   // Credit hold customers cannot place orders unless it's a till sale
   if (SalesHeader."Credit Status" = "On Hold") and (not SalesHeader."Till Sale") then
       Error('Credit status is %1 for this order', SalesHeader."Credit Status");
   ```

2. **Shipment Method Requirement**:
   - All orders must have a shipment method specified
   - Required for logistics and delivery planning

3. **Delivery Date Requirements**:
   - Regular customers (not customer '99999999') must provide:
     - Requested Delivery Date
     - Delivery Date Latest
   - Till sales are exempt from this requirement

#### Credit Memos
- Must specify shipment method for processing
- Subject to same validation as orders where applicable

### Till Sales Exception Handling
**Business Context**: Till sales represent in-store, immediate transactions where different rules apply.

**Special Rules**:
- Bypass credit hold restrictions
- No delivery date requirements
- Simplified processing flow

### Loyalty Point Integration
During sales posting:
1. Points are calculated based on line amounts
2. Points are rounded up to benefit customer
3. Points are credited to participant account
4. Transaction is logged for reconciliation

## Shipment Scheduling System

### Purpose
Manages automated scheduling of recurring shipments for regular customers.

### Business Logic
```al
procedure UpdateShipmentScheduling(var SalesShptLine: Record "Sales Shipment Line")
```

**Process Flow**:
1. **Trigger**: When sales shipment line is created
2. **Conditions**: Only for item lines with non-zero quantity
3. **Processing**:
   - Find existing shipment schedule for customer/item combination
   - Update last shipped quantity
   - Calculate next planned shipment date using GM Functions
   - Mark schedule as 'New' status for processing

**Performance Optimization**:
- Uses `SetLoadFields` to minimize data transfer
- Early exit for non-applicable lines
- Efficient filtering by customer and item

## Agricultural Industry Specifics

### Customer Segmentation
- **Regular Customers**: Full validation and scheduling
- **Till Customers**: Simplified processing
- **Special Customer '99999999'**: Generic/walk-in customer with reduced requirements

### Product Scheduling
The system manages recurring deliveries common in agricultural supply:
- Feed delivery schedules
- Seasonal product availability
- Bulk order planning

### Credit Management
Agricultural customers often have:
- Seasonal payment patterns
- Higher credit limits
- Special credit terms
- Till sale exceptions for immediate needs

## Integration Points

### Standard Business Central Integration
- **Customer Management**: Extends standard customer functionality
- **Sales Processing**: Hooks into sales posting events
- **Inventory**: Links to item management for loyalty calculations
- **Contact Management**: Enhanced contact counting and relationships

### API Endpoints
The system exposes various APIs for integration:
- Loyalty participant management
- Order status tracking
- Product group information
- Production scheduling data

## Error Handling Strategy

### Validation Errors
- Clear, actionable error messages
- Proper use of ErrorInfo for modern BC versions
- Multilingual support through label constants

### Processing Errors
- Graceful degradation where possible
- Comprehensive logging for troubleshooting
- Rollback support for transaction integrity

## Performance Considerations

### Database Optimization
- Strategic use of `SetLoadFields` to reduce data transfer
- Efficient filtering and indexing strategies
- Early exit conditions to avoid unnecessary processing

### Event Subscriber Efficiency
- Minimal processing in high-frequency events
- Conditional logic to process only relevant documents
- Modular procedures for better maintainability

## Maintenance and Monitoring

### Regular Maintenance Tasks
1. **Loyalty Balance Reconciliation**: Weekly verification of point balances
2. **Shipment Schedule Review**: Monthly review of automated schedules
3. **Credit Status Monitoring**: Daily review of credit hold customers

### Key Performance Indicators
- Loyalty program participation rates
- Average order processing time
- Credit hold impact on sales
- API response times

## Troubleshooting Guide

### Common Issues
1. **Loyalty Points Not Calculating**:
   - Check loyalty setup configuration
   - Verify customer participation status
   - Review transaction minimum amounts

2. **Sales Order Validation Failures**:
   - Verify shipment method setup
   - Check credit status configuration
   - Review delivery date requirements

3. **API Error Responses**:
   - Validate participant status (blocked/closed)
   - Check customer linkage
   - Review point balance for redemptions

### Debugging Tips
- Use the comprehensive logging in event subscribers
- Check transaction sequences in loyalty entries
- Review shipment scheduling status updates