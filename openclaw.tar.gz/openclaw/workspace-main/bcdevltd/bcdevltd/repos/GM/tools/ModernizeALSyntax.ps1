# Modernize AL code style - keyword case conversion
param(
    [Parameter(Mandatory=$true)]
    [string]$SourcePath
)
$files = Get-ChildItem -Path $SourcePath -Filter "*.al" -Recurse
foreach ($file in $files) {
    Write-Host "Processing: $($file.FullName)"
    $content = Get-Content $file.FullName -Raw
    
    # Convert keywords to lowercase
    $content = $content -creplace '\bBEGIN\b', 'begin'
    $content = $content -creplace '\bEND\b', 'end'
    $content = $content -creplace '\bIF\b', 'if'
    $content = $content -creplace '\bTHEN\b', 'then'
    $content = $content -creplace '\bELSE\b', 'else'
    $content = $content -creplace '\bWHILE\b', 'while'
    $content = $content -creplace '\bREPEAT\b', 'repeat'
    $content = $content -creplace '\bUNTIL\b', 'until'
    $content = $content -creplace '\bFOR\b', 'for'
    $content = $content -creplace '\bTO\b', 'to'
    $content = $content -creplace '\bDOWNTO\b', 'downto'
    $content = $content -creplace '\bDO\b', 'do'
    $content = $content -creplace '\bCASE\b', 'case'
    $content = $content -creplace '\bOF\b', 'of'
    $content = $content -creplace '\bWITH\b', 'with'
    
    # Convert common methods to PascalCase
    $content = $content -creplace '\.SETRANGE\(', '.SetRange('
    $content = $content -creplace '\.SETFILTER\(', '.SetFilter('
    $content = $content -creplace '\.SETCURRENTKEY\(', '.SetCurrentKey('
    $content = $content -creplace '\.FINDFIRST\(', '.FindFirst('
    $content = $content -creplace '\.FINDLAST\(', '.FindLast('
    $content = $content -creplace '\.FINDSET\(', '.FindSet('
    $content = $content -creplace '\.FIND\(', '.Find('
    $content = $content -creplace '\.INSERT\(', '.Insert('
    $content = $content -creplace '\.MODIFY\(', '.Modify('
    $content = $content -creplace '\.DELETE\(', '.Delete('
    $content = $content -creplace '\.CLEAR\(', '.Clear('
    $content = $content -creplace '\.COUNT\(', '.Count('
    $content = $content -creplace '\.TESTFIELD\(', '.TestField('
    $content = $content -creplace '\.VALIDATE\(', '.Validate('
    $content = $content -creplace '\bCLEAR\(', 'Clear('
    
    # Save modified content
    $content | Set-Content $file.FullName -NoNewline
}
Write-Host "Code style modernization complete!"