$ErrorActionPreference = "Continue"

Write-Host "Checking GitHub authentication..."
gh auth status
if ($LASTEXITCODE -ne 0) {
    Write-Error "You are not logged in to GitHub CLI. Please run 'gh auth login' inside the terminal before running this script."
    exit 1
}

$repoName = Split-Path -Path $PWD -Leaf
$targetRepo = "johntaylormfc/$repoName"
Write-Host "Target Repository: $targetRepo"

if (Test-Path -Path ".git") {
    Write-Host "Wiping existing git history (.git folder)..." -ForegroundColor Yellow
    Remove-Item -Path ".git" -Recurse -Force
}

Write-Host "Init new git repository..." -ForegroundColor Green
git init
git branch -m main
git add .
git commit -m "Clean start"

Write-Host "Checking if repository '$targetRepo' exists on GitHub..."
# Check if repo exists by trying to view it. Capture output to null.
gh repo view $targetRepo | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Host "Repository '$targetRepo' found. DELETING forcefully..." -ForegroundColor Red
    gh repo delete $targetRepo --yes
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to delete repository. Check your permissions/token scopes."
        exit 1
    }
    Start-Sleep -Seconds 3
} else {
    Write-Host "Repository not found. Creating new..." -ForegroundColor Green
}

Write-Host "Creating private repository '$targetRepo' and pushing..." -ForegroundColor Green
gh repo create $targetRepo --private --source=. --remote=origin --push

Write-Host "Operation Complete." -ForegroundColor Cyan
