# Contracts Business Central Extension Overview

## Summary

This extension contains 4 codeunits that implement core business logic. The extension integrates with external systems through External API Integration. It manages custom data through 3 tables. Users interact with the system through 3 custom pages. Key business functions include: ANS (business logic), Financial/Accounting functionality, Get (business logic). This enhances Business Central with specialized functionality tailored to specific business requirements.

## Functionality

- **Publisher**: ANS Group Ltd
- **Extension Name**: Contracts
- **Integration Points**: External API Integration
- **Table**: Unplanned
- **Table**: Third
- **Table**: ANS
- **Extension ID**: f82ace4e-8a1a-46b6-b213-338b5aeb47dd
- **Version**: 1.0.0.24
- **Dependencies**: 1 dependencies
- **AL Files**: Contains 53 AL source files

Generated on 2026-02-05