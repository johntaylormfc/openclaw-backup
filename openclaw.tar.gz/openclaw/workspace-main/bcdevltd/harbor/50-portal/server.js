const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8000; 
const HOST = '127.0.0.1';
const BASE_DIR = path.resolve(__dirname);

console.log(`Harbor starting: BASE_DIR=${BASE_DIR}, PORT=${PORT}`);

const server = http.createServer((req, res) => {
  let urlPath = req.url === '/' ? '/index.html' : req.url;
  
  const requestedPath = path.relative(BASE_DIR, path.resolve(BASE_DIR, urlPath));
  const filePath = path.resolve(BASE_DIR, requestedPath);

  if (!filePath.startsWith(BASE_DIR)) {
    console.error(`ERROR: Path traversal attempt detected: ${req.url}`);
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=UTF-8' });
    res.end('400 Bad Request: Path traversal attempt');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err) {
      console.error(`ERROR serving ${filePath}: ${err.message}`);
      if (req.url === '/status.json') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=UTF-8' });
        res.end(JSON.stringify({ status: 'Error', message: `File not found: ${req.url}`, error: err.message, timestamp: new Date().toISOString() }));
      } else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=UTF-8' });
        res.end('404 Not Found');
      }
      return;
    }

    if (stats.isDirectory()) {
      if (urlPath === '/') {
         urlPath = '/index.html';
         const indexPath = path.resolve(BASE_DIR, urlPath);
         return serveFile(indexPath, 'text/html; charset=UTF-8');
      } else {
         console.error(`ERROR: Attempted to access directory: ${filePath}`);
         res.writeHead(400, { 'Content-Type': 'text/plain; charset=UTF-8' });
         res.end('400 Bad Request: Cannot access directories directly.');
         return;
      }
    }

    if (req.url === '/status.json') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=UTF-8' });
      res.end(JSON.stringify({ status: 'Live', message: 'T0001 Portal operational.', timestamp: new Date().toISOString() }));
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    let contentType = 'text/plain; charset=UTF-8';
    if (ext === '.html') {
      contentType = 'text/html; charset=UTF-8';
    } else if (ext === '.json') {
      contentType = 'application/json; charset=UTF-8';
    } else if (ext === '.css') {
      contentType = 'text/css; charset=UTF-8';
    } else if (ext === '.js') {
      contentType = 'application/javascript; charset=UTF-8';
    } else if (ext === '.png') {
      contentType = 'image/png';
    } else if (ext === '.jpg' || ext === '.jpeg') {
      contentType = 'image/jpeg';
    } else if (ext === '.gif') {
      contentType = 'image/gif';
    } else if (ext === '.ico') {
      contentType = 'image/x-icon';
    }

    serveFile(filePath, contentType);
  });

  function serveFile(fPath, cType) {
    fs.readFile(fPath, (err, data) => {
      if (err) {
        console.error(`ERROR reading file ${fPath}: ${err.message}`);
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=UTF-8' });
        res.end('404 Not Found');
        return;
      }
      res.writeHead(200, { 'Content-Type': cType });
      res.end(data);
    });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Harbor LIVE: http://${HOST}:${PORT}`);
  console.log(`Serving static files from: ${BASE_DIR}`);
});

process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
    process.exit(0);
  });
});
process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
    process.exit(0);
  });
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  server.close(() => {
    console.error('Server closed due to uncaught exception');
    process.exit(1);
  });
});
