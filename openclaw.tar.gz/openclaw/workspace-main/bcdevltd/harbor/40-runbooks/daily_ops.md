# Daily Ops

- Tickets: ls bcdevltd/harbor/10-tickets/
- Status: curl http://127.0.0.1:8787/status.json
- Tasks: cat bcdevltd/tasks/internal_tasks.md
- Approvals: Pending list TBD