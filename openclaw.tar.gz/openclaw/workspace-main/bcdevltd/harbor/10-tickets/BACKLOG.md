# Harbor BACKLOG.md

## T0001: BC Dev Limited Portal (read-only) - COMPLETE ✅ V1 (localhost:8000 static)

## T0005: V2 Portal (localhost:8001) - PARTIAL COMPLETE ✅ (files ready, host run server.py)

## T0006: GM Extension - Add "Johns Test Field" (Text[50]) to Customer Table

**Goal**: Feature branch/PR in johntaylormfc/GM repo adding tableextension Customer with new field "Johns Test Field" (Text[50]).

**Acceptance Criteria**:
- [ ] Research AL extension for standard table (tableextension 18 "Customer" { field(50000; "Johns Test Field"; Text[50]) }).
- [ ] Clone bcdevltd/repos/GM (already done).
- [ ] Feature branch: `feat/johns-test-field`.
- [ ] Add .al file src/tableextension/50000.Customer.al.
- [ ] Update app.json.
- [ ] Test: al test.
- [ ] PR: Summary/risks/verify/rollback (protected branch safe).
- [ ] Team sign-off: Research (AL), Shipwright (code/PR), Inspector (test).

**Owners**: Research (AL guide), Shipwright (branch/PR), Inspector (test), Sentinel (safety).

**Status**: Spawned research agent.

Updated: 2026-02-12 20:27 GMT