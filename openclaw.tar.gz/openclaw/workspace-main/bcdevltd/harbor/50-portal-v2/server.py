#!/usr/bin/env python3
"""Portal V2 HTTP server — port 8001, MIME UTF-8."""
import http.server
import os
import socketserver
import sys

PORT = 8001

class PortalHandler(http.server.SimpleHTTPRequestHandler):
    """Serve files from the script's directory with UTF-8 content types."""

    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        '.html': 'text/html; charset=utf-8',
        '.css':  'text/css; charset=utf-8',
        '.js':   'application/javascript; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.md':   'text/plain; charset=utf-8',
        '.txt':  'text/plain; charset=utf-8',
        '.png':  'image/png',
        '.jpg':  'image/jpeg',
        '.svg':  'image/svg+xml',
        '':      'application/octet-stream',
    }


def main():
    port = PORT
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print(f"Usage: {sys.argv[0]} [port]", file=sys.stderr)
            sys.exit(2)

    base_dir = os.path.abspath(os.path.dirname(__file__) or '.')
    os.chdir(base_dir)

    handler = PortalHandler
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", port), handler) as httpd:
        print(f"Portal V2 serving on http://127.0.0.1:{port}  (dir={base_dir})")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down.")
        finally:
            httpd.server_close()


if __name__ == '__main__':
    main()
