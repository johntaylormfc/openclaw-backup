# Portal Setup - V2 (port 8001)

Overview:
- V2 portal served by Python HTTP server on port 8001
- index.html provides a simple tabbed UI with responsive design
- status.json serves status data at /status.json

Notes:
- This is a minimal skeleton for testing and demonstration.
- For production, replace with a real web server and add assets.

Systemd Service Configuration:
- Service Name: openclaw-harbor-v2.service
- Unit:
  [Unit]
  Description=OpenClaw Harbor V2 Portal Service
  After=network.target

  [Service]
  User=YOUR_USER
  WorkingDirectory=/path/to/your/workspace/bcdevltd/harbor/50-portal-v2
  ExecStart=/usr/bin/python3 /path/to/your/workspace/bcdevltd/harbor/50-portal-v2/server.py 8001
  Restart=on-failure
  RestartSec=5

  [Install]
  WantedBy=multi-user.target
