
import http.server
import socketserver
import os
import sys
import datetime

PORT = 8000
DIRECTORY = "." 

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def do_GET(self):
        log_msg = f"[{datetime.datetime.now().isoformat()}] GET {self.path}"
        print(log_msg, file=sys.stderr) # Log to stderr, which nohup will capture

        if self.path == "/":
            self.path = "/index.html"
        elif self.path == "/status.json":
            self.send_response(200)
            self.send_header("Content-type", "application/json; charset=UTF-8")
            self.end_headers()
            json_content = '{"status": "ok", "message": "T0001 Portal is live", "timestamp": "%s"}' % datetime.datetime.now().isoformat()
            print(f"Serving JSON: {json_content}", file=sys.stderr)
            self.wfile.write(json_content.encode("utf-8"))
            return
        elif self.path.endswith(".html"):
            # Force HTML MIME type for .html files
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=UTF-8")
            self.end_headers()
            try:
                filepath = self.translate_path(self.path)
                with open(filepath, "rb") as f:
                    content = f.read()
                    print(f"Serving HTML file: {filepath}", file=sys.stderr)
                    self.wfile.write(content)
                return
            except FileNotFoundError:
                self.send_error(404, "File not found")
                print(f"File not found: {self.translate_path(self.path)}", file=sys.stderr)
                return
        
        # Default handling for other files
        super().do_GET()
        
server_class = http.server.ThreadingHTTPServer

try:
    httpd = server_class(("localhost", PORT), Handler)
    print(f"Serving at port {PORT} from directory {DIRECTORY}", file=sys.stderr)
    httpd.serve_forever() # This will block, so needs to be in exec with backgrounding
except Exception as e:
    print(f"Server setup error: {e}", file=sys.stderr)
    sys.exit(1)
