# Copilot instructions for Galloway & Macleod (GM) Business Central extension

Purpose

This file gives GitHub Copilot / AI assistants actionable instructions when working on the GM Business Central extension repository. It is based on Microsoft's guidance: "App testing best practices for AL code" (https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/compliance/apptest-bestpracticesforalcode).

What I (Copilot) should prioritize

- Focus on Business Central AL development tasks: reports, pages, codeunits, tables, page extensions, and permission sets under the `src/` tree.
- Follow the repository structure and naming conventions used in this project (for example, `src/Page/`, `src/Table/`, `src/Codeunit/`, `src/API/`).
- When suggesting changes that affect behavior, include tests or guidance for manual test steps (see "Testing" below).
- Preserve existing public APIs and AL object IDs where possible; propose migrations or refactors only with explicit user approval.

Key goals and acceptance criteria

- All suggested code changes must build cleanly with standard Business Central AL tooling.
- Changes to reports and RDLC layouts must not break existing printing/consumption; ensure dataset field names match RDLC reference names.
- Respect localization, permission sets, and extension app.json metadata.

Testing & quality steps (based on MS App testing best practices)

1. Unit and Integration Tests
   - Prefer automated tests where feasible. Add `test` AL objects or use available test frameworks to exercise business logic.
   - Add focused tests for critical codeunit functions, business calculations, and permission-sensitive operations.

2. Manual Test Cases
   - Document manual test steps for UI and RDLC changes. For reports, include steps to verify images, dataset fields, and printed output.
   - For each change, include a short checklist: build, deploy to a sandbox, run scenario, verify results, and capture logs/screenshots.

3. Regression and Acceptance Testing
   - Run existing acceptance/regression flows after making changes. Note any dependencies on data or setup steps.

4. Test Data and Environment
   - Use representative test data and a dedicated sandbox environment when validating changes that touch posting or financial flows.

5. Performance and Stability
   - For heavy operations (reports, batch jobs), include simple performance checks (execution time, memory usage) and document expected baselines.

6. Security and Permissions
   - Verify permission sets (`GM.PermissionSet.al` and `extensionsPermissionSet.xml`). Test least-privilege scenarios.

7. Release and App Validation
   - Ensure `app.json` metadata is accurate and follows Business Central validation rules before generating a new .app.

Practical Copilot behaviors and examples

- When proposing edits to RDLC files, also update AL dataset fields to match. Example: add `CompanyInfo.Name` dataset column and update `StandardSalesInvoice.rdlc` fields and image MIME types.
- If code changes require new permissions, propose updates to `GM.PermissionSet.al` and outline the permission impact.
- For large refactors, propose a migration plan: small incremental PRs, tests, and rollback steps.

Repository-specific notes

- Primary AL source: `src/` (subfolders like `Page/`, `Table/`, `Codeunit/`, `API/`, `Report/`, `PageExt/`).
- Permission set files: `GM.PermissionSet.al` and `extensionsPermissionSet.xml`.
- Temporary/debug files are in `temp/`—avoid committing those unless requested.
- Several prebuilt `.app` files are present in the repo root—do not overwrite them without explicit instruction.

If you're unsure, ask these clarifying questions

- Should I create automated tests or provide manual test steps for this change?
- Do you want changes split into smaller PRs for review?
- Is there an existing sandbox I should reference for test data and validations?

Where to find Microsoft guidance

- App testing best practices for AL code: https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/compliance/apptest-bestpracticesforalcode

Completion

This `copilot-instruction.md` was generated to provide concise, actionable guidance for AI assistants working in this repository. Follow the steps above to ensure changes are safe, testable, and aligned with Microsoft best practices.
