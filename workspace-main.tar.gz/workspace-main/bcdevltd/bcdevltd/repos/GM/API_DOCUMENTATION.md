# GM Extension API Documentation

## Overview
The GM Extension provides a comprehensive REST API for integrating with external systems. All API endpoints follow OData v4 standards and use the `bcdev/operations/v1.0` namespace.

## Base URL Structure
```
https://{bc-instance}.api.businesscentral.dynamics.com/v2.0/{tenant-id}/bcdev/operations/v1.0/
```

## Authentication
All API endpoints require Business Central authentication:
- **Web Services Access Key** for service-to-service calls
- **OAuth 2.0** for user-context applications
- **Certificate-based authentication** for high-security scenarios

### Example Authentication Headers
```http
Authorization: Basic {base64-encoded-credentials}
Content-Type: application/json
```

## API Endpoints

### 1. Contact Management API

#### ContactAPI
- **Endpoint**: `/ContactAPI`
- **Purpose**: Manage contact information
- **Methods**: GET, POST, PATCH, DELETE

```http
GET /ContactAPI
GET /ContactAPI('{contact-id}')
POST /ContactAPI
PATCH /ContactAPI('{contact-id}')
DELETE /ContactAPI('{contact-id}')
```

**Example Request**:
```json
POST /ContactAPI
{
  "name": "John Smith",
  "email": "john.smith@example.com",
  "phoneNo": "+1234567890",
  "companyName": "Acme Corp"
}
```

**Example Response**:
```json
{
  "id": "CONT001",
  "name": "John Smith",
  "email": "john.smith@example.com",
  "phoneNo": "+1234567890",
  "companyName": "Acme Corp",
  "lastModified": "2024-01-15T10:30:00Z"
}
```

### 2. Customer Management API

#### CustomerAPI
- **Endpoint**: `/CustomerAPI`
- **Purpose**: Customer master data management
- **Methods**: GET, POST, PATCH, DELETE

```http
GET /CustomerAPI
GET /CustomerAPI('{customer-no}')
POST /CustomerAPI
PATCH /CustomerAPI('{customer-no}')
```

**Key Fields**:
- `customerNo`: Unique customer identifier
- `name`: Customer name
- `creditLimit`: Credit limit amount
- `paymentTermsCode`: Payment terms
- `loyaltyParticipantNo`: Associated loyalty participant

**Example**:
```json
{
  "customerNo": "CUST001",
  "name": "ABC Manufacturing",
  "creditLimit": 50000.00,
  "paymentTermsCode": "NET30",
  "loyaltyParticipantNo": "LP001"
}
```

### 3. Sales Order Management API

#### SalesOrderAPI
- **Endpoint**: `/SalesOrderAPI`
- **Purpose**: Sales order header management
- **Methods**: GET, POST, PATCH, DELETE

#### SalesOrderLineAPI
- **Endpoint**: `/SalesOrderLineAPI`
- **Purpose**: Sales order line management
- **Methods**: GET, POST, PATCH, DELETE

#### SalesOrderwithLinesAPI
- **Endpoint**: `/SalesOrderwithLinesAPI`
- **Purpose**: Complete sales orders with lines
- **Methods**: GET, POST, PATCH

**Example Sales Order with Lines**:
```json
{
  "documentNo": "SO-001",
  "customerNo": "CUST001",
  "orderDate": "2024-01-15",
  "lines": [
    {
      "lineNo": 10000,
      "itemNo": "ITEM001",
      "quantity": 5,
      "unitPrice": 100.00,
      "lineAmount": 500.00
    },
    {
      "lineNo": 20000,
      "itemNo": "ITEM002", 
      "quantity": 2,
      "unitPrice": 150.00,
      "lineAmount": 300.00
    }
  ]
}
```

### 4. Loyalty Program API

#### LoyaltyParticipantsAPI
- **Endpoint**: `/LoyaltyParticipantsAPI`
- **Purpose**: Loyalty participant management
- **Methods**: GET, POST, PATCH, DELETE

**Bound Actions**:
- `ValidateParticipantForReward`: Validates participant eligibility for rewards
- `ValidateParticipantForRedemption`: Validates participant for points redemption

```http
POST /LoyaltyParticipantsAPI('{participant-no}')/ValidateParticipantForReward
{
  "rewardType": "DISCOUNT",
  "rewardValue": 50.00
}
```

#### LoyaltyCommentsAPI
- **Endpoint**: `/LoyaltyCommentsAPI`
- **Purpose**: Loyalty participant comments
- **Methods**: GET, POST, PATCH, DELETE

### 5. Inventory Management API

#### ItemAPI
- **Endpoint**: `/ItemAPI`
- **Purpose**: Item master data management
- **Methods**: GET, POST, PATCH, DELETE

#### ProductGroupsAPI
- **Endpoint**: `/ProductGroupsAPI`
- **Purpose**: Product group management
- **Methods**: GET, POST, PATCH, DELETE

### 6. Purchase Management API

#### VendorAPI
- **Endpoint**: `/VendorAPI`
- **Purpose**: Vendor master data
- **Methods**: GET, POST, PATCH, DELETE

#### PurchaseOrderPostAPI
- **Endpoint**: `/PurchaseOrderPostAPI`
- **Purpose**: Purchase order posting
- **Methods**: POST

#### PurchaseReturnOrderAPI
- **Endpoint**: `/PurchaseReturnOrderAPI`
- **Purpose**: Purchase return orders
- **Methods**: GET, POST, PATCH, DELETE

### 7. Financial APIs

#### SalesInvoiceAPI
- **Endpoint**: `/SalesInvoiceAPI`
- **Purpose**: Sales invoice management
- **Methods**: GET, POST, PATCH, DELETE

#### GMPostedSalesInvoiceAPI
- **Endpoint**: `/GMPostedSalesInvoiceAPI`
- **Purpose**: Posted sales invoice retrieval
- **Methods**: GET

#### PostedSalesCreditMemoAPI
- **Endpoint**: `/PostedSalesCreditMemoAPI`
- **Purpose**: Posted credit memo retrieval
- **Methods**: GET

### 8. Operations APIs

#### OrderStatusAPI
- **Endpoint**: `/OrderStatusAPI`
- **Purpose**: Order status management
- **Methods**: GET, POST, PATCH, DELETE

#### TransferOrderAPI
- **Endpoint**: `/TransferOrderAPI`
- **Purpose**: Transfer order management
- **Methods**: GET, POST, PATCH, DELETE

#### ProductionScheduleAPI
- **Endpoint**: `/ProductionScheduleAPI`
- **Purpose**: Production scheduling
- **Methods**: GET, POST, PATCH

### 9. Strategy and Analysis APIs

#### StrategyAPI
- **Endpoint**: `/StrategyAPI`
- **Purpose**: Strategic planning data
- **Methods**: GET, POST, PATCH

#### SalespersonPurchaserAPI
- **Endpoint**: `/SalespersonPurchaserAPI`
- **Purpose**: Salesperson and purchaser data
- **Methods**: GET, POST, PATCH, DELETE

#### CreditCommentsAPI
- **Endpoint**: `/CreditCommentsAPI`
- **Purpose**: Credit control comments
- **Methods**: GET, POST, PATCH, DELETE

## Error Handling

All API endpoints implement comprehensive error handling using ErrorInfo objects:

### Standard Error Response Format
```json
{
  "error": {
    "code": "ValidationError",
    "message": "Customer validation failed",
    "details": [
      {
        "code": "CREDIT_LIMIT_EXCEEDED",
        "message": "Customer credit limit of 10,000.00 would be exceeded",
        "target": "creditLimit"
      }
    ]
  }
}
```

### Common Error Codes
- `ValidationError`: Business rule validation failed
- `NotFound`: Requested resource not found
- `Unauthorized`: Authentication/authorization failed
- `Conflict`: Resource conflict (e.g., duplicate key)
- `InternalError`: Unexpected system error

### Error Handling Best Practices
1. **Always check response status codes**
2. **Parse error details for specific error codes**
3. **Implement retry logic for transient errors**
4. **Log errors for debugging and monitoring**

## Rate Limiting and Performance

### Rate Limits
- **Standard APIs**: 100 requests per minute per user
- **Bulk Operations**: 10 requests per minute per user
- **Read Operations**: 200 requests per minute per user

### Performance Optimization
- Use `$select` to retrieve only required fields
- Implement paging with `$top` and `$skip`
- Use `$filter` to minimize data transfer
- Batch operations when possible

**Example Optimized Request**:
```http
GET /CustomerAPI?$select=customerNo,name,creditLimit&$filter=creditLimit gt 5000&$top=50
```

## Webhooks and Events

### Available Webhooks
- Customer Creation/Update
- Sales Order Status Changes
- Loyalty Points Transactions
- Invoice Posting Events

### Webhook Configuration
```json
{
  "subscriptionId": "webhook-001",
  "callbackUrl": "https://your-system.com/webhooks/gm",
  "events": ["customer.created", "salesorder.statusChanged"],
  "secretKey": "your-secret-key"
}
```

## SDK and Integration Examples

### .NET SDK Example
```csharp
using GM.BusinessCentral.API;

var client = new GMAPIClient("https://bc-instance.api.businesscentral.dynamics.com/");
client.SetAuthentication(username, accessKey);

// Get customer
var customer = await client.Customers.GetAsync("CUST001");

// Create sales order
var salesOrder = new SalesOrder
{
    CustomerNo = "CUST001",
    OrderDate = DateTime.Now,
    Lines = new List<SalesOrderLine>
    {
        new SalesOrderLine { ItemNo = "ITEM001", Quantity = 5, UnitPrice = 100 }
    }
};
await client.SalesOrders.CreateAsync(salesOrder);
```

### PowerShell Example
```powershell
# Set up authentication
$credentials = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("$($username):$($accessKey)"))
$headers = @{ Authorization = "Basic $credentials" }

# Get loyalty participants
$participants = Invoke-RestMethod -Uri "$baseUrl/LoyaltyParticipantsAPI" -Headers $headers

# Validate participant for reward
$validateRequest = @{
    rewardType = "DISCOUNT"
    rewardValue = 25.00
} | ConvertTo-Json

Invoke-RestMethod -Uri "$baseUrl/LoyaltyParticipantsAPI('LP001')/ValidateParticipantForReward" `
    -Method POST -Body $validateRequest -Headers $headers -ContentType "application/json"
```

### JavaScript/Node.js Example
```javascript
const axios = require('axios');

const apiClient = axios.create({
  baseURL: 'https://bc-instance.api.businesscentral.dynamics.com/v2.0/tenant-id/bcdev/operations/v1.0/',
  headers: {
    'Authorization': `Basic ${Buffer.from(`${username}:${accessKey}`).toString('base64')}`,
    'Content-Type': 'application/json'
  }
});

// Get sales orders
const salesOrders = await apiClient.get('/SalesOrderAPI');

// Create customer
const customer = await apiClient.post('/CustomerAPI', {
  name: 'New Customer',
  creditLimit: 25000.00,
  paymentTermsCode: 'NET30'
});
```

## Testing and Development

### Test Environment
- **Base URL**: `https://bc-test.api.businesscentral.dynamics.com/`
- **Test Data**: Use "TEST-" prefix for all test records
- **Rate Limits**: Relaxed for testing (500 requests/minute)

### API Testing Tools
- **Postman Collection**: Available in `/tools/GM-API.postman_collection.json`
- **Test Scripts**: Automated validation scripts in `/tests/api/`
- **Mock Server**: Local testing server for development

## Support and Troubleshooting

### API Monitoring
- Health endpoint: `/health`
- Status page: `https://status.gmextension.com`
- Performance metrics: Available via telemetry

### Common Issues
1. **Authentication Failures**: Check credentials and permissions
2. **Timeout Errors**: Reduce batch sizes or implement retry logic  
3. **Validation Errors**: Review business rules and required fields
4. **Rate Limiting**: Implement exponential backoff

### Getting Help
- **Documentation**: [GM API Docs](https://docs.gmextension.com)
- **Support Email**: api-support@gallowayandmacleod.com
- **Developer Forum**: [GM Developer Community](https://community.gmextension.com)
- **Status Updates**: Follow [@GM_API](https://twitter.com/GM_API) for updates

## Version History

### v1.1.0 (Current)
- Enhanced error handling with ErrorInfo objects
- Added loyalty participant validation actions
- Improved performance monitoring
- Added webhook support

### v1.0.0
- Initial API release
- Core CRUD operations
- Basic authentication
- Standard OData compliance

## Deprecation Policy

- **Major versions**: Supported for 2 years
- **Minor versions**: Supported for 1 year  
- **Deprecation notice**: 6 months advance warning
- **Breaking changes**: Only in major version updates