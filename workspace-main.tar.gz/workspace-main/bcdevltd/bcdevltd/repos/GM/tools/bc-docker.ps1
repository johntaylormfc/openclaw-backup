# Docker Scripts for BC Development

param(
    [Parameter(Mandatory = $false)]
    [string]$Action = "help",
    
    [Parameter(Mandatory = $false)]
    [string]$ContainerName = "bc-dev",
    
    [Parameter(Mandatory = $false)]
    [string]$BCVersion = "10.0.26100.2314-ltsc2022-dev",
    
    [Parameter(Mandatory = $false)]
    [string]$Password = "",
    
    [Parameter(Mandatory = $false)]
    [string]$LicenseFile = ""
)

function Show-Help {
    Write-Host "Business Central Docker Management Script" -ForegroundColor Green
    Write-Host ""
    Write-Host "Usage: .\bc-docker.ps1 -Action <action> [options]" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Actions:" -ForegroundColor Cyan
    Write-Host "  pull      - Pull the latest BC container image"
    Write-Host "  create    - Create a new BC development container" 
    Write-Host "  start     - Start existing container"
    Write-Host "  stop      - Stop running container"
    Write-Host "  restart   - Restart container"
    Write-Host "  remove    - Remove container (data will be lost)"
    Write-Host "  logs      - View container logs"
    Write-Host "  status    - Show container status"
    Write-Host "  connect   - Connect to container shell"
    Write-Host "  symbols   - Download BC symbols"
    Write-Host "  publish   - Publish extension (requires -AppFile)"
    Write-Host "  help      - Show this help"
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Cyan
    Write-Host "  -ContainerName  Container name (default: bc-dev)"
    Write-Host "  -BCVersion      BC image version (default: 10.0.26100.2314-ltsc2022-dev)"
    Write-Host "  -Password       Admin password (auto-generated if not specified)"
    Write-Host "  -LicenseFile    Path to BC license file"
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  .\bc-docker.ps1 -Action pull"
    Write-Host "  .\bc-docker.ps1 -Action create -Password 'MySecurePassword'"
    Write-Host "  .\bc-docker.ps1 -Action start"
    Write-Host "  .\bc-docker.ps1 -Action symbols"
}

function Test-DockerRunning {
    try {
        docker info | Out-Null
        return $true
    }
    catch {
        Write-Error "Docker is not running. Please start Docker Desktop."
        return $false
    }
}

function Pull-BCImage {
    Write-Host "Pulling BC container image: mcr.microsoft.com/businesscentral:$BCVersion" -ForegroundColor Green
    docker pull mcr.microsoft.com/businesscentral:$BCVersion
}

function Create-BCContainer {
    if (-not (Test-DockerRunning)) { return }
    
    # Check if container already exists
    $existingContainer = docker ps -a --filter "name=$ContainerName" --format "{{.Names}}"
    if ($existingContainer -eq $ContainerName) {
        Write-Warning "Container '$ContainerName' already exists. Use -Action remove to delete it first."
        return
    }
    
    # Generate password if not provided
    if ([string]::IsNullOrEmpty($Password)) {
        $Password = -join ((1..12) | ForEach-Object { [char]((65..90) + (97..122) + (48..57) | Get-Random) })
        Write-Host "Generated password: $Password" -ForegroundColor Yellow
    }
    
    # Build docker command
    $dockerArgs = @(
        "run", "-d"
        "--name", $ContainerName
        "-p", "7047-7049:7047-7049"
        "-p", "8080:80"
        "-v", "${PWD}:/workspace"
        "-e", "accept_eula=Y"
        "-e", "accept_outdated=Y"
        "-e", "username=admin"
        "-e", "password=$Password"
    )
    
    # Add license file if provided
    if (-not [string]::IsNullOrEmpty($LicenseFile) -and (Test-Path $LicenseFile)) {
        $dockerArgs += "-v"
        $dockerArgs += "${LicenseFile}:/run/my/license.bclicense"
        $dockerArgs += "-e"
        $dockerArgs += "licensefile=/run/my/license.bclicense"
    }
    
    $dockerArgs += "mcr.microsoft.com/businesscentral:$BCVersion"
    
    Write-Host "Creating BC container..." -ForegroundColor Green
    & docker @dockerArgs
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Container '$ContainerName' created successfully!" -ForegroundColor Green
        Write-Host "Admin credentials - Username: admin, Password: $Password" -ForegroundColor Yellow
        Write-Host "Web client will be available at: http://localhost:8080" -ForegroundColor Cyan
    }
}

function Start-BCContainer {
    Write-Host "Starting container '$ContainerName'..." -ForegroundColor Green
    docker start $ContainerName
}

function Stop-BCContainer {
    Write-Host "Stopping container '$ContainerName'..." -ForegroundColor Green
    docker stop $ContainerName
}

function Restart-BCContainer {
    Write-Host "Restarting container '$ContainerName'..." -ForegroundColor Green
    docker restart $ContainerName
}

function Remove-BCContainer {
    Write-Host "Removing container '$ContainerName'..." -ForegroundColor Red
    $confirmation = Read-Host "This will delete all container data. Continue? (y/N)"
    if ($confirmation -eq 'y' -or $confirmation -eq 'Y') {
        docker rm -f $ContainerName
        Write-Host "Container removed." -ForegroundColor Green
    }
}

function Show-Logs {
    docker logs $ContainerName
}

function Show-Status {
    $container = docker ps -a --filter "name=$ContainerName" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
    if ($container) {
        Write-Host $container
    }
    else {
        Write-Host "Container '$ContainerName' not found." -ForegroundColor Red
    }
}

function Connect-Container {
    Write-Host "Connecting to container shell..." -ForegroundColor Green
    docker exec -it $ContainerName powershell
}

function Download-Symbols {
    Write-Host "Downloading BC symbols..." -ForegroundColor Green
    docker exec $ContainerName powershell "Download-Symbols -ServerInstance BC -Tenant default"
}

# Main script logic
switch ($Action.ToLower()) {
    "help" { Show-Help }
    "pull" { Pull-BCImage }
    "create" { Create-BCContainer }
    "start" { Start-BCContainer }
    "stop" { Stop-BCContainer } 
    "restart" { Restart-BCContainer }
    "remove" { Remove-BCContainer }
    "logs" { Show-Logs }
    "status" { Show-Status }
    "connect" { Connect-Container }
    "symbols" { Download-Symbols }
    default { 
        Write-Error "Unknown action: $Action"
        Show-Help
    }
}