# Standard Sales Invoice RDLC Layout - Implementation Details

## Overview
This document describes the RDLC layout created for the Sales Invoice report extension (Report 65620) that extends the standard Business Central Report 1306 "Standard Sales - Invoice".

## Layout Structure

The RDLC layout (`StandardSalesInvoice.rdlc`) has been designed to match the NAV 5.0 invoice format as shown in the customer's screenshot while incorporating all GM custom fields.

### Page Setup
- **Page Size**: 8.5" x 11" (Letter)
- **Margins**: 0.25" on all sides
- **Report Unit**: Inches
- **Body Height**: 7.5"
- **Body Width**: 8"

## Layout Sections

### 1. Header Section (0.1" - 1.6")

#### Company Logo and Title
- **Company Logo**: Image control displaying Company Information Picture
  - Position: Top-left
  - Size: 2.5" x 0.8"
  - Sizing: FitProportional
  
- **Invoice Title**: "Sales - Invoice"
  - Position: Top-right
  - Font: 16pt Bold
  - Alignment: Right

#### Company Information
- Company Name (9pt Bold)
- Address Line
- City and Post Code
- All positioned below logo

### 2. Customer and Invoice Details Section (1.6" - 3.6")

#### Bill-to Customer Section (Left Side)
- **Bill-to Customer No.** and value
- **Customer Name** (9pt Bold)
- **Address** (8pt)
- **City** (8pt)
- **Post Code** (8pt)
- **Border**: Solid box with padding

#### Invoice Details Section (Right Side)
- **Invoice No.** with value
- **Order No.** with value
- **Posting date** (formatted as dd/MM/yy)
- **Due Date** (formatted as dd/MM/yy)
- **Shipment Method**
- **Served by** (Salesperson)
- **Border**: Solid box with padding

#### Ship-to Address Section (Below Bill-to)
- **Ship-to Address** label
- **Name** (9pt Bold)
- **Address** (8pt)
- **City** (8pt)
- **Post Code** (8pt)
- **Border**: Solid box with padding

#### UFAS Certificate Information (Right Lower)
- Text: "UFAS Compound Feeds and UFAS Merchant Certificate No. 80 End Date 31/05/25"
- Font: 8pt
- Position: Right side, below invoice details

### 3. Line Items Table (3.7" - 4.35")

**Table Structure**: Tablix with 7 columns

#### Column Headers (Bold, 8pt):
1. **Shipment Date** (0.6")
2. **Item No.** (0.85")
3. **Description** (2.5") - Widest column
4. **Quantity** (0.7") - Right aligned
5. **Unit of Measure** (0.9")
6. **Unit Price** (0.9") - Right aligned, formatted as #,##0.000
7. **VAT %** (0.9") - Center aligned

#### Data Rows:
- **First Row**: Displays item details (Shipment Date, Item No, Description, Quantity, UOM, Unit Price, VAT%)
- **Second Row**: Amount display row
  - Spans 6 columns (left blank)
  - "Amount:" label in 6th column (Bold)
  - Amount value in 7th column (Right aligned, formatted as #,##0.00)
  
#### Formatting:
- All cells have solid borders
- 2pt padding on all sides
- Quantity and prices right-aligned
- VAT% center-aligned

### 4. VAT Summary Table (4.45" - 5.05")

**Table Structure**: Tablix with 4 columns

#### Columns:
1. **VAT Code** (1.5") - Left aligned
2. **VAT %** (1") - Center aligned
3. **VAT Base** (1.5") - Right aligned, formatted as #,##0.00
4. **VAT Amount** (1.5") - Right aligned, formatted as #,##0.00

#### Rows:
- **Header Row**: Column titles (Bold, 8pt)
- **Data Row**: VAT details per VAT code
- **Total Row**: "Total" label with total VAT Base and total VAT Amount (Bold)

### 5. Invoice Total (5.15" - 5.5")

- **Label**: "Invoice Total:" (10pt Bold, Right aligned)
- **Value**: Total Amount Including VAT (10pt Bold, Right aligned)
- **Value Border**: 2pt solid border
- **Position**: Right side of page
- **Size**: 3" wide x 0.35" high

### 6. Payment Terms (5.6" - 6.2")

**Text Content** (7pt, Red color, Center aligned):
```
Terms of payment

You are reminded that under our Terms & Conditions of Sale (which apply to all sales of goods and supplies of services by us) payment is due by date ordered above, failing which payment for all sales and supplies falls immediately due

All goods remain our property until we have received payment in full
```

### 7. Footer Section (6.3" - 7.2")

**Company Details** (All center-aligned):

1. **Company Name**: "Galloway & MacLeod Limited" (8pt Bold)
2. **Address**: "King Street     South Lanarkshire, ML9 2EH     tel: 01698 791919     fax: 01698 793079" (7pt)
3. **Contact**: "email: info@galloway-macleod.co.uk     web: www.galloway-macleod.co.uk     vat reg. no.: 200 1735 64" (7pt)
4. **Bank Details**: "bank: Barclays Bank plc     sortcode: 203370     account: 30435795/43587524" (7pt)
5. **Email Notice**: "INVOICES SENT BY E-MAIL" (7pt Italic)

## GM Custom Fields Integration

### Dataset Fields Available (Not Currently Displayed in Layout)

The following GM custom fields are defined in the dataset and available for use:

#### Header Fields (_GM suffix):
- ShipToMobileNo_GM
- ShipToMobileNo2_GM
- OldShipToPhoneNo_GM
- LoyaltyCardNo_GM
- LoyaltyPoints_GM
- Cash_GM
- Cheque_GM
- CreditCard_GM
- Change_GM
- BalanceDue_GM
- Deposit_GM
- WriteOff_GM
- CustomerPO_GM
- CustomerReference_GM

#### Line Fields (_LineGM suffix):
- LoyaltyPoints_LineGM
- BonusPoints_LineGM
- ProductGroupCode_LineGM
- Haulage_LineGM
- LoyaltyDiscount_LineGM

**Note**: These fields are defined in the dataset but not currently placed on the report layout. They can be added by modifying the RDLC file in Visual Studio or Report Builder if needed.

## Standard BC Report 1306 Fields Used

The layout utilizes these standard fields from Report 1306:

### Company Information:
- CompanyInfo_Name
- CompanyInfo_Picture
- CompanyInfo_Address
- CompanyInfo_City
- CompanyInfo_PostCode
- CompanyInfo_PhoneNo
- CompanyInfo_Email
- CompanyInfo_VATRegistrationNo
- CompanyInfo_BankName
- CompanyInfo_BankAccountNo

### Invoice Header:
- No_SalesInvoiceHeader
- OrderNo_SalesInvoiceHeader
- PostingDate_SalesInvoiceHeader
- DueDate
- DocumentDate
- ShipmentDate
- ShipmentMethodDescription
- SalespersonText
- BillToCustomerNo
- BillToName
- BillToAddress
- BillToCity
- BillToPostCode
- ShipToName
- ShipToAddress
- ShipToCity
- ShipToPostCode

### Invoice Lines:
- No_SalesInvoiceLine (Item No.)
- Description_SalesInvoiceLine
- Quantity_SalesInvoiceLine
- UnitOfMeasure_SalesInvoiceLine
- UnitPrice
- VATPct_SalesInvoiceLine
- LineAmount_SalesInvoiceLine

### Totals:
- TotalAmount (VAT Base)
- TotalAmountVAT
- TotalAmountInclVAT (Invoice Total)

### VAT:
- VATAmountLine_VATIdentifier
- VATAmountLine_VATPct
- VATAmountLine_VATBase
- VATAmountLine_VATAmount

## Design Decisions

### Matching NAV 5.0 Format
1. **Layout Structure**: Two-column design with customer info on left, invoice details on right
2. **Line Items**: 7-column table with amount on separate row (matching screenshot)
3. **VAT Summary**: Separate table below line items
4. **Colors**: Red text for payment terms (as shown in screenshot)
5. **Footer**: Multi-line company details in center

### Font Sizes
- **Titles**: 16pt (Invoice Title), 10pt (Invoice Total)
- **Names/Bold Items**: 9pt
- **Standard Text**: 8pt
- **Footer Text**: 7pt

### Borders and Spacing
- Solid borders on all major sections
- 2-5pt padding for readability
- Consistent spacing between sections

### Number Formatting
- **Quantities**: #,##0.00 (2 decimal places)
- **Prices**: #,##0.000 (3 decimal places for unit price)
- **Amounts**: #,##0.00 (2 decimal places)
- **VAT %**: 0 (whole number)
- **Dates**: dd/MM/yy format

## Customization Notes

### To Add GM Custom Fields to the Layout:

1. Open the RDLC file in Visual Studio or SQL Server Report Builder
2. The fields are already defined in the DataSet
3. Add new Textbox controls to desired locations
4. Set the Value property to reference the field, e.g., `=Fields!LoyaltyCardNo_GM.Value`
5. Apply appropriate formatting and positioning

### Common Customization Locations:

- **Ship-to Contact Info**: Add mobile numbers below ship-to address
- **Loyalty Information**: Add loyalty card and points in invoice details section
- **Payment Details**: Add Cash, Cheque, Credit Card amounts near invoice total
- **Customer Reference**: Add CustomerPO_GM and CustomerReference_GM in header

## Testing Notes

### Validation Performed:
- ✅ XML structure validated using Python ElementTree
- ✅ Report namespace correct: `http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition`
- ✅ All textbox and tablix elements properly structured
- ✅ All field references use standard BC naming conventions
- ✅ File size: 110KB, 2791 lines

### Recommended Testing in BC:
1. Deploy the extension to Business Central
2. Navigate to Report Layouts page
3. Find Report 1306 "Standard Sales - Invoice"
4. Select "Standard Sales Invoice (GM)" layout
5. Preview with a test posted sales invoice
6. Verify all sections display correctly
7. Check page breaks and layout fit
8. Test with invoices containing multiple lines
9. Test with different VAT configurations
10. Verify logo displays correctly

## Known Limitations

1. **Company Logo**: Requires Company Information Picture to be set
2. **UFAS Certificate**: Hard-coded text, may need to be dynamic
3. **Footer Details**: Hard-coded company information, should ideally pull from Company Information
4. **GM Fields**: Defined but not displayed - requires manual placement
5. **Multiple Pages**: Report may need page header/footer definitions for multi-page invoices

## Future Enhancements

Potential improvements:
1. Add page header/footer for multi-page invoices
2. Add page numbers
3. Display GM custom fields (loyalty, payment details)
4. Make footer information dynamic from Company Information
5. Add conditional visibility for certain sections
6. Support for multiple languages
7. Add QR code for payment
8. Include barcode for invoice number
9. Add terms and conditions from setup tables
10. Support for logo in footer

## File Information

- **File Path**: `./src/ReportExt/Layout/StandardSalesInvoice.rdlc`
- **Report Extension**: 65620 "Standard Sales Invoice GM"
- **Base Report**: 1306 "Standard Sales - Invoice"
- **Created**: 2024
- **Format**: RDLC (RDL Client-side)
- **Schema Version**: 2016/01
- **Lines**: 2791
- **Size**: ~110KB

## References

- Report Extension File: `./src/ReportExt/StandardSalesInvoiceExt.ReportExt.al`
- Documentation: `./src/ReportExt/StandardSalesInvoice.README.md`
- Implementation Guide: `./src/ReportExt/IMPLEMENTATION_GUIDE.md`
- Quick Reference: `./src/ReportExt/QUICK_REFERENCE.md`
- NAV 5.0 Screenshot: Provided in issue description (shows expected output format)
