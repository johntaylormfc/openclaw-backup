#!/bin/bash
set -e

DATE=$(date +%Y%m%d%H%M)
BACKUP_DIR="$HOME/.openclaw-backup/$DATE"
mkdir -p "$BACKUP_DIR"

echo "Backing up OpenClaw to $BACKUP_DIR"

tar --exclude=".git/**" -czf "$BACKUP_DIR/openclaw.tar.gz" -C "$HOME" .openclaw
tar --exclude=".git/**" -czf "$BACKUP_DIR/workspace-main.tar.gz" -C "$HOME/.openclaw" workspace-main

cd "$BACKUP_DIR"
git init
git config user.name "OpenClaw Backup"
git config user.email "john@johntaylormfc.com"

git add .
git commit -m "Hourly $DATE backup (tar, .git excluded)"

BRANCH="hourly-$DATE"
git checkout -b "$BRANCH"

git remote add origin https://github.com/johntaylormfc/openclaw-backup.git || git remote set-url origin https://github.com/johntaylormfc/openclaw-backup.git
git push -u origin "$BRANCH"

gh pr create --title "Hourly Backup $DATE" --body "Auto-backup PR. Review/merge." --base main

echo "PR: $(gh pr view --json url --jq .url 2>/dev/null || echo 'Check GH')"
